const animationControls = Object.fromEntries(["front", "rear"].map(face => [face, {
    effect: document.getElementById(face + "Effect"),
    speed: document.getElementById(face + "Speed"),
    row: document.getElementById(face + "SpeedRow"),
    value: document.getElementById(face + "SpeedValue")
}]));
function updateAnimationControls() {
    for (const c of Object.values(animationControls)) {
        c.row.hidden = c.effect.value === "solid";
        c.value.textContent = c.speed.value + " %";
    }
}

const timeElement =
    document.getElementById("time");

const statusElement =
    document.getElementById("status");

const frontColor =
    document.getElementById("frontColor");

const rearColor =
    document.getElementById("rearColor");

const brightness =
    document.getElementById("brightness");

const brightnessValue =
    document.getElementById("brightnessValue");

const harmony =
    document.getElementById("harmony");

const harmonyDescription =
    document.getElementById("harmonyDescription");

const manualRearRow =
    document.getElementById("manualRearRow");

const automaticRearRow =
    document.getElementById("automaticRearRow");

const effectiveRearColor =
    document.getElementById("effectiveRearColor");

const frontPreview =
    document.getElementById("frontPreview");

const rearPreview =
    document.getElementById("rearPreview");

const themeList =
    document.getElementById("themeList");

const activeTheme =
    document.getElementById("activeTheme");

const message =
    document.getElementById("message");


let themes = [];

let themeTimer = null;

let pending = false;

let currentRequest = null;

let applyingTheme = false;

let initialized = false;

let revision = 0;

let effectiveRear = "#3c64b4";


const harmonyDescriptions = {

    "manual":
        "Deux couleurs entièrement indépendantes.",

    "identical":
        "La même couleur à l'avant et à l'arrière.",

    "complementary":
        "Une couleur opposée sur le cercle chromatique.",

    "analogous-plus":
        "Une couleur voisine, décalée de +30°.",

    "analogous-minus":
        "Une couleur voisine, décalée de -30°.",

    "triadic":
        "Une couleur décalée de 120°."

};


// ======================================================
// HTTP API
// ======================================================

// One local HTTP request at a time, including body consumption. The ESP8266
// has a small heap and handles clients sequentially. Maintenance can exclude
// normal requests while a release is in progress.
window.WordclockLocal = (() => {
    let tail = Promise.resolve(), maintenance = false;
    return {
        get busy() { return maintenance; },
        setBusy(value) { maintenance = value; },
        run(task, privileged=false) {
            const next = tail.then(() => {
                if (maintenance && !privileged) throw Error('Mise à jour en cours');
                return task();
            });
            tail = next.catch(() => {});
            return next;
        }
    };
})();

async function request(url, options = {}) {
    return window.WordclockLocal.run(async () => {
    const response = await fetch(url, {

        cache: "no-store",
        signal: AbortSignal.timeout(10000),
        ...options

    });

    if (!response.ok) {

        throw new Error(
            "HTTP " + response.status
        );
    }

    return await response.json();
    });
}


// ======================================================
// Messages
// ======================================================

function showMessage(text, error = false) {

    message.textContent = text;

    message.classList.toggle(
        "error",
        error
    );
}


// ======================================================
// System status
// ======================================================

let clockAnchor = null;
function tickLocalClock() {
    if (!clockAnchor) return;
    const sec=(clockAnchor.seconds+Math.floor((performance.now()-clockAnchor.at)/1000))%86400;
    const h=Math.floor(sec/3600),m=Math.floor(sec/60)%60;
    homeTime=[h,m];
    timeElement.textContent=[h,m,sec%60].map(n=>String(n).padStart(2,'0')).join(':');
}
setInterval(tickLocalClock,1000);
async function updateStatus() {
    if (window.WordclockLocal.busy || document.hidden) { setTimeout(updateStatus,5000); return; }
    try {

        const data =
            await request("/api/status");

        timeElement.textContent =
            data.timeValid
                ? data.time
                : "--:--:--";

        const match=data.timeValid&&/^(\d{2}):(\d{2})/.exec(data.time);
        homeTime=match?[Number(match[1]),Number(match[2])]:[-1,-1];
        const full=data.timeValid&&/^(\d{2}):(\d{2}):(\d{2})$/.exec(data.time);
        clockAnchor=full?{seconds:Number(full[1])*3600+Number(full[2])*60+Number(full[3]),at:performance.now()}:null;
        statusElement.textContent =
            "Connectée";

        statusElement.style.color =
            "var(--success)";

    } catch (error) {

        statusElement.textContent =
            "Connexion perdue";

        statusElement.style.color =
            "var(--error)";

        clockAnchor=null;
        homeTime=[-1,-1];
        timeElement.textContent =
            "--:--:--";

    } finally {

        setTimeout(updateStatus, 5000);
    }
}


// ======================================================
// User controls
// ======================================================

let frontBrightness = 100;
let rearBrightness = 100;
function setControlsEnabled(enabled) {
    document.getElementById("powerToggle").disabled = !enabled;

    frontColor.disabled = !enabled;

    rearColor.disabled = !enabled;

    brightness.disabled = !enabled;

    harmony.disabled = !enabled;
    for (const c of Object.values(animationControls)) { c.effect.disabled = !enabled; c.speed.disabled = !enabled; }

    document.getElementById("homeTheme").textContent=activeTheme.textContent;
    themeList
        .querySelectorAll(".theme-card")
        .forEach(button => {

            button.disabled = !enabled;
        });
}

function updateBrightnessLabel() {

    document.getElementById("powerToggle").textContent=Number(brightness.value)===0?"Allumer":"Éteindre";
    if(Number(brightness.value)>0){lastBrightness=Number(brightness.value);try{localStorage.setItem("wordclock-last-brightness",String(lastBrightness));}catch(e){}}
    brightnessValue.textContent =

        Math.round(
            Number(brightness.value) / 255 * 100
        ) + " %";
}


// ======================================================
// Palette preview
// ======================================================

function readableTextColor(hex) {

    const rgb = parseInt(
        hex.replace("#", ""),
        16
    );

    const r = (rgb >> 16) & 255;

    const g = (rgb >> 8) & 255;

    const b = rgb & 255;

    const luminance =

        (r * 299 + g * 587 + b * 114) / 1000;

    return luminance > 155

        ? "#000000"

        : "#ffffff";
}

function setPreviewColor(element, color) {

    element.style.backgroundColor = color;

    element.style.color =
        readableTextColor(color);
}

function updatePalettePreview() {

    const rear = harmony.value === "manual"

        ? rearColor.value

        : effectiveRear;

    setPreviewColor(
        frontPreview,
        frontColor.value
    );

    setPreviewColor(
        rearPreview,
        rear
    );

    effectiveRearColor.style.backgroundColor =
        rear;

    effectiveRearColor.title =
        rear.toUpperCase();
}


// ======================================================
// Harmony controls
// ======================================================

function updateHarmonyControls() {

    const manual =
        harmony.value === "manual";

    manualRearRow.hidden = !manual;

    automaticRearRow.hidden = manual;

    harmonyDescription.textContent =
        harmonyDescriptions[harmony.value] || "";

    updatePalettePreview();
}


// ======================================================
// Synchronize controls
// ======================================================

function updateControls(data) {
    for (const [face,c] of Object.entries(animationControls)) {
        c.effect.value = data[face + "Effect"] || "solid";
        c.speed.value = data[face + "Speed"] ?? 50;
    }
    updateAnimationControls();

    frontColor.value =
        data.front.toLowerCase();

    rearColor.value =
        data.rear.toLowerCase();

    brightness.value =
        data.brightness;
    frontBrightness = data.frontBrightness ?? 100;
    rearBrightness = data.rearBrightness ?? 100;

    harmony.value =
        data.harmony || "manual";

    effectiveRear =

        (
            data.effectiveRear ||
            data.rear
        ).toLowerCase();

    updateBrightnessLabel();

    updateHarmonyControls();

    updateActiveTheme();
}


// ======================================================
// Active theme detection
// ======================================================

function updateActiveTheme() {

    let selected = null;

    {

        selected = themes.find(theme =>

            (theme.harmony || "manual") === harmony.value &&

            theme.front.toLowerCase() ===
            frontColor.value.toLowerCase() &&

            theme.rear.toLowerCase() ===
            rearColor.value.toLowerCase() &&
            (theme.frontBrightness ?? 100) === frontBrightness &&
            (theme.rearBrightness ?? 100) === rearBrightness &&
            ["front", "rear"].every(face => {
                const c = animationControls[face];
                const effect = theme[face + "Effect"] || "solid";
                return effect === c.effect.value && (effect === "solid" || Number(c.speed.value) === (theme[face + "Speed"] ?? 50));
            })
        );
    }

    activeTheme.textContent =

        selected

            ? selected.name

            : "Personnalisé";

    document.getElementById("homeTheme").textContent=activeTheme.textContent;
    themeList
        .querySelectorAll(".theme-card")
        .forEach(button => {

            const isActive =

                !!selected &&

                button.dataset.id === selected.id;

            button.classList.toggle(
                "active",
                isActive
            );

            button.setAttribute(
                "aria-pressed",
                String(isActive)
            );
        });
}


// ======================================================
// Theme library
// ======================================================

function renderThemeLibrary() {

    themeList.replaceChildren();

    for (const theme of themes) {

        const button =
            document.createElement("button");

        button.type = "button";

        button.className = "theme-card";

        button.dataset.id = theme.id;

        const preview =
            document.createElement("div");

        preview.className = "theme-preview";

        const v = window.WordclockStudioVisual;
        const f = v.rgb(theme.front);
        const offsets = {identical:0,complementary:180,'analogous-plus':30,'analogous-minus':-30,triadic:120};
        const r = theme.harmony && theme.harmony !== 'manual' ? v.rotate(f, offsets[theme.harmony] ?? 0) : v.rgb(theme.rear);
        const fl = (theme.frontBrightness ?? 100) / 100;
        const rl = (theme.rearBrightness ?? 100) / 100;
        preview.style.setProperty('--front', fl === 0 ? 'var(--face-unlit,#393939)' : v.css(f.map(n=>n*(0.45+0.55*Math.pow(fl,0.4)))));
        preview.style.setProperty('--rear', v.css(r.map(n=>n*(rl>0?0.45+0.55*Math.pow(rl,0.4):0))));
        if(rl === 0) preview.style.boxShadow = 'none';
        v.matrixPreview(preview);

        const name =
            document.createElement("span");

        name.className = "theme-name";

        name.textContent = theme.name;
        if (theme.id.startsWith("custom-")) {
            name.textContent += " (Perso)";
        }

        const colors =
            document.createElement("div");

        colors.className = "theme-colors";

        for (const color of [
            theme.front,
            theme.rear
        ]) {

            const dot =
                document.createElement("span");

            dot.className = "color-dot";

            dot.style.backgroundColor = color;

            colors.appendChild(dot);
        }

        button.append(
            preview,
            name,
            colors
        );

        button.addEventListener(
            "click",
            () => applyTheme(theme.id)
        );

        const tile=document.createElement('div');tile.className='library-tile';
        const more=document.createElement('button');more.type='button';more.className='library-action library-more';more.textContent='Options';more.setAttribute('aria-label','Options : '+theme.name);
        more.addEventListener('click',()=>window.wordclockLibrary.open(theme.id));
        tile.append(button,more);themeList.appendChild(tile);
    }

    updateActiveTheme();

    setControlsEnabled(
        initialized && !applyingTheme
    );
}


// ======================================================
// Initialization
// ======================================================

async function initialize() {
    if (window.WordclockLocal.busy) { setTimeout(initialize,3000); return; }
    setControlsEnabled(false);

    try {

        const data =
            await request("/api/theme");

        if (!data.harmony || !data.frontEffect || !data.rearEffect) {

            throw new Error(
                "Firmware update required"
            );
        }

        updateControls(data);

        themes =
            await request("/api/themes?version=3");

        initialized = true;

        renderThemeLibrary();

        setControlsEnabled(true);

        showMessage("");

    } catch (error) {

        showMessage(

            "Impossible de charger les paramètres : " +
            error.message,

            true
        );

        setTimeout(initialize, 3000);
    }
}


// ======================================================
// Manual theme updates
// ======================================================

function sendTheme() {

    if (!initialized || applyingTheme) {

        return;
    }

    if (currentRequest) {

        pending = true;

        return;
    }

    pending = false;

    const requestRevision = revision;

    const params = new URLSearchParams({

        front: frontColor.value,

        rear: rearColor.value,

        brightness: brightness.value,

        harmony: harmony.value,
        frontEffect: animationControls.front.effect.value,
        rearEffect: animationControls.rear.effect.value,
        frontSpeed: animationControls.front.speed.value,
        rearSpeed: animationControls.rear.speed.value

    });

    currentRequest = request(

        "/api/theme",

        {

            method: "POST",

            body: params

        }

    )

        .then(data => {

            // Ignore stale responses.

            if (
                requestRevision === revision &&
                !applyingTheme
            ) {

                updateControls(data);

                showMessage(
                    "Réglages appliqués"
                );
            }
        })

        .catch(error => {

            if (requestRevision === revision) {

                showMessage(

                    "Impossible d'appliquer les réglages.",

                    true
                );
            }
        })

        .finally(() => {

            currentRequest = null;

            if (pending && !applyingTheme) {

                sendTheme();
            }
        });
}

function scheduleThemeUpdate() {

    revision++;
    updateAnimationControls();

    updateBrightnessLabel();

    updateHarmonyControls();

    updateActiveTheme();

    clearTimeout(themeTimer);

    themeTimer = setTimeout(
        sendTheme,
        100
    );
}


// ======================================================
// Apply predefined theme
// ======================================================

async function applyTheme(id) {

    if (applyingTheme || !initialized) {

        return false;
    }

    applyingTheme = true;

    revision++;

    clearTimeout(themeTimer);

    pending = false;

    setControlsEnabled(false);

    if (currentRequest) {

        await currentRequest;
    }

    try {

        // Preserve the latest brightness.

        await request(

            "/api/theme",

            {

                method: "POST",

                body: new URLSearchParams({

                    brightness: brightness.value

                })

            }
        );

        const data = await request(

            "/api/themes/apply",

            {

                method: "POST",

                body: new URLSearchParams({
                    id
                })

            }
        );

        updateControls(data);

        showMessage("Thème appliqué");
        return true;

    } catch (error) {

        showMessage(

            "Impossible d'appliquer le thème.",

            true
        );

        try {

            const data =
                await request("/api/theme");

            updateControls(data);

        } catch (syncError) {

            console.error(syncError);
        }

        return false;

    } finally {

        applyingTheme = false;

        setControlsEnabled(true);
    }
}


// ======================================================
// Event listeners
// ======================================================

frontColor.addEventListener(

    "input",

    scheduleThemeUpdate

);

rearColor.addEventListener(

    "input",

    scheduleThemeUpdate

);

brightness.addEventListener(

    "input",

    scheduleThemeUpdate

);

harmony.addEventListener(

    "change",

    scheduleThemeUpdate

);


// ======================================================
// Start
// ======================================================

let homeTime=[-1,-1], lastBrightness=8, nightPreview=null;
try {const n=Number(localStorage.getItem('wordclock-last-brightness'));if(Number.isInteger(n)&&n>0&&n<=255)lastBrightness=n;}catch(e){}
const powerToggle=document.getElementById('powerToggle');
powerToggle.addEventListener('click',()=>{brightness.value=Number(brightness.value)?0:lastBrightness;scheduleThemeUpdate();});
document.addEventListener('wordclock:night-status',e=>{nightPreview=e.detail;});
// Defer initialization until all deferred scripts have executed.
document.addEventListener('DOMContentLoaded',()=>{
    const v=window.WordclockStudioVisual, el=document.querySelector('.home-preview');
    const setTime=v.matrixPreview(el,-1,-1);
    let previous='', lastKey='', start=performance.now();
    function draw(now){
        if(!document.hidden&&!document.getElementById('homeView').hidden){
            const key=homeTime.join(':');if(key!==previous){setTime(...homeTime);previous=key;}
            const effectKey=[frontColor.value,rearColor.value,harmony.value,...Object.values(animationControls).flatMap(c=>[c.effect.value,c.speed.value])].join(':');
            if(effectKey!==lastKey){start=now;lastKey=effectKey;}
            let g=initialized?Number(brightness.value):0;
            if(nightPreview?.active)g=nightPreview.mode===2?0:Math.min(g,nightPreview.brightness);
            const screenLevel=n=>n>0?0.45+0.55*Math.pow(n,0.4):0;
            const scale=(c,n)=>v.css(c.map(x=>x*screenLevel(n)));
            const f=v.rgb(frontColor.value),r=v.rgb(harmony.value==='manual'?rearColor.value:effectiveRear);
            const fc=v.effect(f,{...animationControls.front,start},now);
            const rc=Array.from({length:20},(_,i)=>v.effect(r,{...animationControls.rear,start},now,i));
            // Screen contrast is perceptual, not a linear LED power measurement.
            const frontLevel=g/255*Number(frontBrightness)/100;
            const peak=Math.max(...fc);
            const perceptual=frontLevel>0&&peak>0 ? screenLevel(frontLevel) : 0;
            const normalization=peak>0 ? Math.max(1,235/Math.max(...f,1)) : 1;
            const displayFront=fc.map(x=>x*normalization*perceptual);
            el.style.setProperty('--front',v.css(displayFront));
            const rearScale=nightPreview?.active&&nightPreview.mode===1?0:g/255*Number(rearBrightness)/100;
            const groups=Array.from({length:4},(_,side)=>{const a=rc.slice(side*5,side*5+5);return scale([0,1,2].map(k=>a.reduce((sum,c)=>sum+c[k],0)/5),rearScale);});
            el.style.boxShadow=`0 12px 24px 4px ${groups[0]}, -12px 0 24px 4px ${groups[1]}, 0 -12px 24px 4px ${groups[2]}, 12px 0 24px 4px ${groups[3]}`;
            el.classList.toggle('rear-off',rearScale===0);
            el.classList.toggle('front-off',g===0||Number(frontBrightness)===0);
        }
        setTimeout(()=>requestAnimationFrame(draw),50);
    }
    requestAnimationFrame(draw);updateStatus();initialize();
});

const transitionEnabled = document.getElementById("transitionEnabled");
const transitionDuration = document.getElementById("transitionDuration");
const transitionValue = document.getElementById("transitionValue");
const transitionReset = document.getElementById("transitionReset");
const transitionMessage = document.getElementById("transitionMessage");
let transitionBusy = true;
function updateTransitionUI() {
    transitionEnabled.disabled = transitionBusy;
    transitionDuration.disabled = transitionBusy || !transitionEnabled.checked;
    transitionReset.disabled = transitionBusy;
    transitionValue.textContent = transitionEnabled.checked ? (Number(transitionDuration.value)/1000).toLocaleString("fr-CH", {minimumFractionDigits:1, maximumFractionDigits:1}) + " s" : "Instantané";
}
function showTransition(data) {
    transitionEnabled.checked = data.duration > 0;
    if (data.duration > 0) transitionDuration.value = data.duration;
}
async function loadTransitions() {
    try { showTransition(await request("/api/transitions")); transitionBusy = false; transitionMessage.textContent = ""; }
    catch (e) { transitionMessage.textContent = "Réglages indisponibles, nouvelle tentative…"; setTimeout(loadTransitions, 3000); }
    updateTransitionUI();
}
async function saveTransitions() {
    if (transitionBusy) return;
    transitionBusy = true; updateTransitionUI();
    try {
        showTransition(await request("/api/transitions", {method:"POST", body:new URLSearchParams({duration:transitionEnabled.checked ? transitionDuration.value : "0"})}));
        transitionMessage.textContent = "Réglage appliqué";
    } catch (e) {
        transitionMessage.textContent = "Échec de la modification";
        try { showTransition(await request("/api/transitions")); } catch (ignored) { setTimeout(loadTransitions, 3000); return; }
    }
    transitionBusy = false; updateTransitionUI();
}
transitionEnabled.addEventListener("change", saveTransitions);
transitionDuration.addEventListener("input", updateTransitionUI);
transitionDuration.addEventListener("change", saveTransitions);
transitionReset.addEventListener("click", () => { transitionEnabled.checked = true; transitionDuration.value = 1500; saveTransitions(); });
loadTransitions();

for (const c of Object.values(animationControls)) {
    c.effect.addEventListener("change", scheduleThemeUpdate);
    c.speed.addEventListener("input", scheduleThemeUpdate);
}

async function refreshThemeLibrary() {
    themes = await request("/api/themes?version=3");
    renderThemeLibrary();
}

// Browser-local appearance, independent of device settings.
const appearanceToggle=document.getElementById('appearanceToggle');
function setAppearance(dark){document.documentElement.dataset.appearance=dark?'dark':'light';appearanceToggle.textContent=dark?'Mode clair':'Mode sombre';appearanceToggle.setAttribute('aria-pressed',String(dark));}
let darkAppearance=false;try{darkAppearance=localStorage.getItem('wordclock-appearance')==='dark';}catch(e){}
setAppearance(darkAppearance);
appearanceToggle.addEventListener('click',()=>{darkAppearance=!darkAppearance;setAppearance(darkAppearance);try{localStorage.setItem('wordclock-appearance',darkAppearance?'dark':'light');}catch(e){}});

// Device-wide physical face color. Preview only; never changes theme data.
(()=>{
 const fields=document.getElementById('faceFields'), picker=document.getElementById('facePicker'), msg=document.getElementById('faceMessage'), presets=document.getElementById('facePresets');
 const sample=document.getElementById('faceSample');
 const colors=[['Noir','#151515'],['Blanc','#F5F5F5'],['Anthracite','#454545'],['Gris','#909090'],['Rouge','#A13835'],['Bleu','#304D70'],['Vert','#536B49'],['Terracotta','#B46B50']];
 let saved='#151515',busy=false;
 function paint(el,c){const rgb=[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));const l=rgb[0]*.299+rgb[1]*.587+rgb[2]*.114;const v=rgb.map(n=>Math.round(n*.78+(l>135?0:255)*.22));el.style.setProperty('--face-color',c);el.style.setProperty('--face-unlit',`rgb(${v.join(',')})`);}
 function draft(c){picker.value=c;paint(sample,c);for(const b of presets.children)b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===c.toLowerCase()));}
 function apply(c){saved=c;paint(document.documentElement,c);draft(c);}
 for(const [name,c] of colors){const b=document.createElement('button');b.type='button';b.dataset.color=c;const sw=document.createElement('span');sw.className='face-swatch';sw.style.background=c;b.append(sw,document.createTextNode(name));b.addEventListener('click',()=>{draft(c);saveFace();});presets.append(b);}
 picker.addEventListener('input',()=>draft(picker.value));
 async function load(){try{const data=await request('/api/appearance');if(!/^#[0-9a-f]{6}$/i.test(data.faceColor))throw Error('Invalid color');apply(data.faceColor);fields.disabled=false;msg.textContent='';}catch(e){msg.textContent='Apparence indisponible. Nouvelle tentative…';setTimeout(load,3000);}}
 picker.addEventListener('change',saveFace);
 async function saveFace(){if(busy)return;busy=true;fields.disabled=true;try{const data=await request('/api/appearance',{method:'POST',body:new URLSearchParams({faceColor:picker.value})});apply(data.faceColor);msg.textContent='Couleur appliquée';}catch(e){draft(saved);msg.textContent='Échec de la modification';}finally{busy=false;fields.disabled=false;}}
 function init(){
    try { window.WordclockStudioVisual.matrixPreview(sample); }
    catch (error) { console.error('Face preview initialization failed', error); }
    load();
 }
 // Deferred scripts execute while readyState is interactive, before DOMContentLoaded.
 document.addEventListener('DOMContentLoaded', init, {once:true});
})();


(() => {
    document.addEventListener("DOMContentLoaded", () => {
        const el = id => document.getElementById(id);
        const change = el("wifiChange"), forget = el("wifiForget"), message = el("wifiMessage");
        let busy = false;
        function enable(value) { change.disabled = forget.disabled = !value; }
        async function refresh() {
            if (busy) return;
            try {
                const data = await request("/api/wifi");
                el("wifiSsid").textContent = data.ssid || "—";
                el("wifiIp").textContent = data.ip;
                el("wifiHost").textContent = data.hostname;
                el("wifiState").textContent = data.connected ? "Connectée" : "Déconnectée";
                enable(data.connected);
            } catch (_) { el("wifiState").textContent = "Indisponible"; enable(false); }
        }
        async function act(action) {
            if (busy || !confirm(action === "forget" ? "Effacer les identifiants Wi-Fi et redémarrer ? Les thèmes sont conservés." : "Ouvrir le portail Wi-Fi ? Cette interface sera temporairement inaccessible.")) return;
            busy = true; enable(false);
            message.textContent = "Authentification administrateur requise…";
            try {
                await request("/api/wifi", {method:"POST", headers:{"X-Wordclock-Action":"wifi"}, body:new URLSearchParams({action})});
                message.textContent = "Commande acceptée. Connecte-toi à Wordclock-Setup (mot de passe : Wordclock123), puis ouvre http://192.168.4.1. Après configuration, recharge cette page.";
            } catch (err) {
                message.textContent = "Commande non confirmée : " + err.message + ". Vérifie si le portail est apparu avant de réessayer.";
                busy = false; refresh();
            }
        }
        change.addEventListener("click", () => act("change"));
        forget.addEventListener("click", () => act("forget"));
        el("settingsTab").addEventListener("click", refresh);
        refresh();
    });
})();

// Local access and browser shortcut guidance (works on plain HTTP).
document.addEventListener('DOMContentLoaded', () => {
    const el = id => document.getElementById(id);
    const host = el('accessHost'), ip = el('accessIp'), message = el('accessMessage');
    if (!host || !ip || !message) return;
    async function copy(field) {
        if (!field.value) return;
        try {
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(field.value);
            else { field.focus(); field.select(); field.setSelectionRange(0, field.value.length); if (!document.execCommand('copy')) throw new Error('copy'); }
            message.textContent = 'Adresse copiée.';
        } catch (_) { field.focus(); field.select(); message.textContent = 'Adresse sélectionnée : copiez-la manuellement.'; }
    }
    el('copyHost').addEventListener('click', () => copy(host));
    el('copyIp').addEventListener('click', () => copy(ip));
    async function refreshAccess() {
        try {
            const data = await request('/api/wifi');
            ip.value = data.connected && /^\d{1,3}(\.\d{1,3}){3}$/.test(data.ip) ? 'http://' + data.ip + '/' : '';
        } catch (_) { ip.value = ''; }
        el('copyIp').disabled = !ip.value;
    }
    const platform = el('accessPlatform');
    const help = {android: 'Dans Chrome, ouvrez le menu ⋮ puis Ajouter à l’écran d’accueil (ou Créer un raccourci), et confirmez.',ios: 'Dans Safari, ouvrez Partager, puis Sur l’écran d’accueil et confirmez.',windows: 'Dans Chrome, recherchez Créer un raccourci dans le menu. Sinon, sur le bureau Windows, clic droit > Nouveau > Raccourci et saisissez http://wordclock.local/.'};
    platform.value = /Android/i.test(navigator.userAgent) ? 'android' : /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) ? 'ios' : 'windows';
    function updateHelp() { el('accessHelp').textContent = help[platform.value]; }
    platform.addEventListener('change', updateHelp); updateHelp();
    el('settingsTab').addEventListener('click', refreshAccess);
    refreshAccess();
});

;
(() => {
    'use strict';
    const el = id => document.getElementById(id);
    const fields = el('nightFields'), enabled = el('nightEnabled'), start = el('nightStart'), end = el('nightEnd'), mode = el('nightMode'), brightness = el('nightBrightness');
    const defaults = {enabled:false,startMinute:1350,endMinute:420,brightness:13,mode:0};
    let ready = false, busy = false, dirty = false, timer;
    const toTime = n => `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
    const toMinute = s => { const [h,m] = s.split(':').map(Number); return h*60+m; };
    function message(text, error=false) { el('nightMessage').textContent=text; el('nightMessage').classList.toggle('error',error); }
    function preview() {
        el('nightBrightnessValue').textContent = `${(Number(brightness.value)*100/255).toFixed(1).replace('.',',')} %`;
        el('nightBrightnessRow').hidden = mode.value === '2';
        el('nightHint').textContent = start.value === end.value ? 'Horaires identiques : le mode nuit ne s’activera pas.' : 'La luminosité nocturne est un plafond. Les horaires utilisent l’heure locale de l’horloge.';
    }
    function fill(n) { enabled.checked=n.enabled; start.value=toTime(n.startMinute); end.value=toTime(n.endMinute); mode.value=String(n.mode); brightness.value=String(n.brightness); preview(); }
    function status(n) { document.dispatchEvent(new CustomEvent("wordclock:night-status",{detail:n})); const e=el('nightStatus'); e.textContent=n.active?'Actif':n.enabled?'Programmé':'Désactivé'; e.classList.toggle('active',n.active); }
    async function request(options={}) { return window.WordclockLocal.run(async()=>{ const r=await fetch('/api/night',{cache:'no-store',...options}); if(!r.ok) throw Error(`HTTP ${r.status}`); return await r.json(); }); }
    async function poll() {
        if (!busy && !window.WordclockLocal.busy && !document.hidden) {
            busy=true;
            try { const n=await request(); status(n); if(!dirty) fill(n); if(!ready){ready=true;fields.disabled=false;message('');} }
            catch(e){el('nightStatus').textContent='Indisponible';el('nightStatus').classList.remove('active'); if(!ready) message('Mode nuit inaccessible : '+e.message,true);}
            finally {busy=false;}
        }
        setTimeout(poll,30000);
    }
    function schedule() { dirty=true;preview();clearTimeout(timer);message('Enregistrement en attente…');timer=setTimeout(save,500); }
    el('nightForm').addEventListener('input',schedule);
    el('nightForm').addEventListener('change',schedule);
    el('nightReset').addEventListener('click',()=>{fill(defaults);schedule();});
    el('nightForm').addEventListener('submit',e=>{e.preventDefault();schedule();});
    async function save(){
        if(!ready || !dirty || fields.disabled) return;
        if(!el('nightForm').checkValidity()){message('Veuillez renseigner des horaires valides.',true);return;}
        // A status poll may be in progress; let it finish before writing.
        while(busy) { await new Promise(resolve=>setTimeout(resolve,50)); }
        if(fields.disabled || !dirty) return;
        clearTimeout(timer);
        const body=new URLSearchParams({enabled:enabled.checked?'1':'0',startMinute:String(toMinute(start.value)),endMinute:String(toMinute(end.value)),brightness:brightness.value,mode:mode.value});
        busy=true;fields.disabled=true;message("Envoi en cours…");
        try { const n=await request({method:'POST',body});fill(n);status(n);dirty=false;message('Paramètres appliqués.'); }
        catch(e){dirty=true;message('Échec de l’enregistrement : '+e.message,true);}
        finally {busy=false;fields.disabled=false;}
    }
    poll();
})();

;
(() => {
    'use strict';
    function validate(data){
        data.name=data.name.trim();data.author=data.author.trim();data.description=data.description.trim();
        if(!data.name)throw new Error('Indiquez un nom.');
        for(const [key,max] of [['name',48],['author',48],['description',200]]) {
            if(new TextEncoder().encode(data[key]).length>max)throw new Error('Texte trop long : '+key+' (limite '+max+' octets UTF-8).');
            if(/[\x00-\x1f\x7f]/.test(data[key]))throw new Error('Les caractères de contrôle et retours à la ligne ne sont pas acceptés.');
        }
    }
    function validateImport(data) {
        if(!data || typeof data!=='object' || Array.isArray(data) || ![2,3].includes(data.version)) throw new Error('Format de thème version 2 ou 3 requis.');
        const bytes=s=>new TextEncoder().encode(s).length;
        function text(key,max,required=false,fallback) {
            const v=data[key]===undefined?fallback:data[key];
            if(typeof v!=='string'||bytes(v)>max||/[\x00-\x1f\x7f]/.test(v)||(required&&!v.trim())) throw new Error('Champ invalide : '+key);
            return v;
        }
        if(data.id!==undefined && (typeof data.id!=='string'||data.id.length>48||!/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(data.id))) throw new Error('Identifiant invalide.');
        const result={version:3,name:text('name',48,true),author:text('author',48),description:text('description',200,false,'')};
        for(const key of ['front','rear']) {
            if(typeof data[key]!=='string'||!/^#[0-9a-fA-F]{6}$/.test(data[key])) throw new Error('Couleur invalide : '+key);
            result[key]=data[key];
        }
        for(const [key,options] of Object.entries({harmony:['manual','identical','complementary','analogous-plus','analogous-minus','triadic'],frontEffect:['solid','breathing','color-cycle'],rearEffect:['solid','breathing','color-cycle','rainbow','chase']})) {
            const value=key==='harmony'&&data[key]===undefined?'manual':data[key];
            if(!options.includes(value)) throw new Error('Valeur invalide : '+key);
            result[key]=value;
        }
        for(const key of ['frontSpeed','rearSpeed']) {
            if(!Number.isInteger(data[key])||data[key]<0||data[key]>100) throw new Error('Vitesse invalide : '+key);
            result[key]=data[key];
        }
        for(const key of ['frontBrightness','rearBrightness']) { const v=data.version===2?100:data[key]; if(!Number.isInteger(v)||v<0||v>100)throw new Error('Luminosité invalide : '+key);result[key]=v; }
        if(bytes(JSON.stringify(result))>2048) throw new Error('Thème trop volumineux.');
        return result;
    }
    // Compare portable fields, not device-specific identifiers.
    const nameKey=n=>n.trim().normalize('NFC').toLowerCase();
    function uniqueName(name,pool){
        const used=new Set(pool.map(t=>nameKey(t.name)));
        if(!used.has(nameKey(name)))return name;
        const base=name.replace(/ \(Copie(?: \d+)?\)$/i,'');
        for(let i=1;;i++){
            const suffix=i===1?' (Copie)':` (Copie ${i})`;
            let stem=base;
            while(new TextEncoder().encode(stem+suffix).length>48)stem=Array.from(stem).slice(0,-1).join('');
            const candidate=stem.trimEnd()+suffix;
            if(!used.has(nameKey(candidate)))return candidate;
        }
    }
    function fingerprint(t){
        const v=validateImport(t);validate(v);
        v.name=nameKey(v.name);v.front=v.front.toLowerCase();v.rear=v.rear.toLowerCase();
        return JSON.stringify(v);
    }
    function planImport(theme,pool){
        validate(theme);
        if(pool.some(t=>fingerprint(t)===fingerprint(theme)))return null;
        return {...theme,name:uniqueName(theme.name,pool)};
    }
    function prepareSave(theme,pool,checkIdentical){
        return checkIdentical?planImport(theme,pool):{...theme,name:uniqueName(theme.name,pool)};
    }
    window.WordclockThemeRules=Object.freeze({validate,validateImport,uniqueName,fingerprint,planImport,prepareSave});
})();

;
(() => {
    'use strict';
    const byId=id=>document.getElementById(id);
    const matrix = ['ILAESTBDEUX','QUATREDCINQ','SIXNEUFONZE','UNEHSEPTDIX','HUITFTROISZ','UMIDIHEURES','MINUITSETFA','MOINSOVINGT','DIXTLESDEMI','QUARTUCINQO','WGBSDLO****'];
    function timePixels(hour, minute) {
        const lit=new Set();
        if(!Number.isInteger(hour)||hour<0||hour>23||!Number.isInteger(minute)||minute<0||minute>59)return lit;
        const add=(start,length)=>{for(let i=0;i<length;i++)lit.add(start+i);};
        const step=Math.floor(minute/5);
        if(step>=7)hour=(hour+1)%24;
        add(0,2);add(3,3);
        const hours=[[66,6],[33,3],[7,4],[49,5],[11,6],[18,4],[22,3],[37,4],[44,4],[25,4],[41,3],[29,4]];
        if(hour===12)add(56,4);else {add(...hours[hour%12]);if(hour!==0)add(60,hour%12===1?5:6);}
        const mins=[[],[[105,4]],[[88,3]],[[73,2],[99,5]],[[83,5]],[[83,5],[105,4]],[[73,2],[95,4]],[[77,5],[83,5],[105,4]],[[77,5],[83,5]],[[77,5],[92,2],[99,5]],[[77,5],[88,3]],[[77,5],[105,4]]];
        mins[step].forEach(w=>add(...w));add(117,minute%5);return lit;
    }
    function matrixPreview(element,hour=8,minute=0) {
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 110 110');svg.setAttribute('aria-hidden','true');
        const cells=Array.from(matrix.join(''),(letter,i)=>{const t=document.createElementNS(svg.namespaceURI,'text');t.setAttribute('x',String(5+i%11*10));t.setAttribute('y',String(8+Math.floor(i/11)*10));t.textContent=letter==='*'?'·':letter;svg.append(t);return t;});
        element.replaceChildren(svg);element.classList.add('matrix-preview');
        function setTime(h,m){const lit=timePixels(h,m);cells.forEach((c,i)=>c.classList.toggle('lit',lit.has(i)));}
        setTime(hour,minute);return setTime;
    }
    const rgb = hex => [1,3,5].map(i => parseInt(hex.slice(i,i+2),16));
    const css = c => '#' + c.map(x => Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join('');
    function hsv(c) {
        const [r,g,b] = c.map(x=>x/255), v=Math.max(r,g,b), d=v-Math.min(r,g,b);
        let h=0;
        if(d) h=60*(v===r?(g-b)/d:v===g?(b-r)/d+2:(r-g)/d+4);
        return [(h+360)%360,v?d/v:0,v];
    }
    function fromHsv(h,s,v) {
        h=((h%360)+360)%360;
        const c=v*s,x=c*(1-Math.abs(h/60%2-1)),m=v-c;
        return [[c,x,0],[x,c,0],[0,c,x],[0,x,c],[x,0,c],[c,0,x]][Math.floor(h/60)].map(n=>Math.round((n+m)*255));
    }
    function rotate(c,degrees) { const [h,s,v]=hsv(c); return fromHsv(h+degrees,s,v); }
    const period=c=>30000-290*Number(c.speed.value);
    function effect(base,c,now,i=0) {
        const t=((now-c.start)%period(c))/period(c);
        const phase=Math.floor(t*256)/256;
        let level=255;
        switch(c.effect.value) {
            case 'solid': return base;
            case 'breathing': level=40+215*(1+Math.cos(phase*2*Math.PI))/2; break;
            case 'color-cycle': return rotate(base,t*360);
            case 'rainbow': return fromHsv((Math.floor(i*256/20)/256-phase)*360,1,Math.max(...base)/255);
            case 'chase': level=12+243*Math.pow((1+Math.cos((Math.floor(i*256/20)/256-phase)*2*Math.PI))/2,4); break;
        }
        return base.map(n=>n?Math.min(255,Math.floor(n*Math.floor(level)/256)+1):0);
    }
    window.WordclockStudioVisual=Object.freeze({timePixels,matrixPreview,rgb,css,rotate,effect});
})();

;
// Local theme library only. Full editor is preserved in studio-legacy/.
(() => {
    'use strict';
    const el=id=>document.getElementById(id);
    const {validateImport,planImport}=window.WordclockThemeRules;
    const dialog=el('libraryDialog'), actions=el('libraryActions');
    let busy=false;
    const message=text=>{el('libraryMessage').textContent=text; if(dialog.open)el('libraryDialogMessage').textContent=text;};
    for(const [id,view] of [['homeTab','homeView'],['themesTab','libraryView'],['settingsTab','settingsView']]) {
        el(id).addEventListener('click',()=>{
            for(const v of ['homeView','libraryView','settingsView'])el(v).hidden=v!==view;
            for(const tab of ['homeTab','themesTab','settingsTab'])el(tab).setAttribute('aria-pressed',String(tab===id));
        });
    }
    function api(method,id='',data){
        return request('/api/themes/custom?version=3'+(id?'&id='+encodeURIComponent(id):''),{method,...(data?{headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}:{})});
    }
    async function run(fn){
        if(busy||window.WordclockLocal.busy)return;
        busy=true;
        const buttons=[el('libraryImport'),el('libraryBackup'),el('libraryClose'),...actions.querySelectorAll('button')];
        buttons.forEach(b=>b.disabled=true);
        try{await fn();}catch(e){message('Erreur : '+e.message);}finally{busy=false;buttons.forEach(b=>b.disabled=false);}
    }
    function download(data,name){
        const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)+'\n'],{type:'application/json'}));
        const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
    }
    async function saved(t){return t.id.startsWith('custom-')?api('GET',t.id):t;}
    window.wordclockLibrary={open(id){
        if(busy||dialog.open)return;
        const t=themes.find(x=>x.id===id);if(!t)return;
        el('libraryTitle').textContent=t.name;el('libraryDialogMessage').textContent='';actions.replaceChildren();
        function action(label,fn){const b=document.createElement('button');b.type='button';b.className='library-action';b.textContent=label;b.addEventListener('click',()=>run(fn));actions.append(b);}
        action('Appliquer',async()=>{if(!await applyTheme(id))throw Error('Application non confirmée');dialog.close();});
        action('Exporter',async()=>{download({...validateImport(await saved(t)),id},id+'.json');dialog.close();});
        if(id.startsWith('custom-'))action('Supprimer',async()=>{if(!confirm('Supprimer « '+t.name+' » ?'))return;const r=await api('DELETE',id);if(!r.ok)throw Error('Suppression non confirmée');await refreshThemeLibrary();message('Thème supprimé.');dialog.close();});
        dialog.showModal();
    }};
    el('libraryClose').addEventListener('click',()=>{if(!busy)dialog.close();});
    dialog.addEventListener('cancel',e=>{if(busy)e.preventDefault();});
    const file=el('libraryFile');
    el('libraryImport').addEventListener('click',()=>{file.value='';file.click();});
    file.addEventListener('change',()=>{const f=file.files[0];file.value='';if(!f)return;run(async()=>{
        if(f.size>256*1024)throw Error('Fichier trop volumineux');
        const raw=JSON.parse(await f.text());
        const entries=raw.format==='wordclock-theme-collection'&&raw.version===1?raw.themes:[raw];
        if(!Array.isArray(entries)||!entries.length||entries.length>30)throw Error('Collection invalide');
        const incoming=entries.map(validateImport);await refreshThemeLibrary();
        const pool=themes.slice(), planned=[];
        for(const t of incoming){const next=planImport(t,pool);if(next){planned.push(next);pool.push(next);}}
        if(themes.filter(t=>t.id.startsWith('custom-')).length+planned.length>30)throw Error('Bibliothèque pleine');
        if(!planned.length){message('Thèmes déjà présents.');return;}
        if(!confirm('Importer '+planned.length+' thème(s) ?'))return;
        let count=0;
        try{for(const t of planned){const r=await api('POST','',t);if(!r.id?.startsWith('custom-'))throw Error('Création non confirmée');count++;}}
        catch(e){throw Error(count+'/'+planned.length+' importé(s) : '+e.message+' — actualisez avant de réessayer.');}
        finally{try{await refreshThemeLibrary();}catch{}}
        message(count+'/'+planned.length+' thème(s) importé(s).');
    });});
    el('libraryBackup').addEventListener('click',()=>run(async()=>{
        await refreshThemeLibrary();const entries=[];
        for(const t of themes.filter(t=>t.id.startsWith('custom-')))entries.push({...validateImport(await saved(t)),id:t.id});
        download({format:'wordclock-theme-collection',version:1,themes:entries},'wordclock-themes.json');
    }));
})();

;
(() => {
'use strict';
const el = id => document.getElementById(id);
const zones = [['Europe/Zurich','Suisse — Zurich'],['Europe/Paris','France — Paris'],['Europe/Berlin','Allemagne — Berlin'],['Europe/London','Royaume-Uni — Londres'],['Europe/Lisbon','Portugal — Lisbonne'],['Europe/Athens','Grèce — Athènes'],['Etc/UTC','UTC'],['America/New_York','États-Unis — New York'],['America/Toronto','Canada — Toronto'],['America/Los_Angeles','États-Unis — Los Angeles'],['Asia/Tokyo','Japon — Tokyo']];
const colors = [['Noir','#151515'],['Blanc','#F5F5F5'],['Anthracite','#454545'],['Gris','#909090'],['Rouge','#A13835'],['Bleu','#304D70'],['Vert','#536B49'],['Terracotta','#B46B50']];
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
async function api(path, data) {
 return window.WordclockLocal.run(async()=>{
 const controller = new AbortController(); const timeout=setTimeout(()=>controller.abort(),5000);
 try { const response=await fetch(path,{cache:'no-store',signal:controller.signal,...(data?{method:'POST',body:new URLSearchParams(data)}:{})}); if(!response.ok) throw Error('HTTP '+response.status); return await response.json(); } finally {clearTimeout(timeout);}
 });
}
let installPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;});
window.addEventListener('appinstalled',()=>{installPrompt=null;const d=el('shortcutDialog');if(d&&d.open)d.close();});
document.addEventListener('DOMContentLoaded',()=>{
 const dialog=el('setupDialog'), name=el('setupName'), zone=el('setupZone'), color=el('setupColor'), message=el('setupMessage'), next=el('setupNext'), back=el('setupBack'), skip=el('setupSkip'), open=el('setupOpen');
 let step=0,busy=false,original=null;
 const shortcut=el('shortcutDialog');
 function offerShortcut(){
  const mobile=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
  if((!mobile&&!installPrompt)||navigator.standalone||matchMedia('(display-mode: standalone)').matches)return;
  el('shortcutAdd').hidden=false;el('shortcutHelp').hidden=true;el('shortcutAddressHelp').hidden=true;el('shortcutClose').textContent='Plus tard';
  if(!shortcut.open)shortcut.showModal();
 }
 el('shortcutAdd').onclick=async()=>{
  if(installPrompt){const prompt=installPrompt;installPrompt=null;try{await prompt.prompt();const choice=await prompt.userChoice;if(choice.outcome==='accepted'){shortcut.close();return;}return;}catch(error){/* Native prompt unavailable: show manual instructions. */}}
  const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
  el('shortcutHelp').textContent=ios?'Dans Safari, touchez Partager, puis Sur l’écran d’accueil.':/Android/i.test(navigator.userAgent)?'Dans Chrome, ouvrez le menu ⋮, puis Ajouter à l’écran d’accueil (ou Créer un raccourci).':'Utilisez le menu de votre navigateur pour installer cette page ou créer un raccourci, si cette option est disponible.';
  el('shortcutHelp').hidden=false;
  const note=el('shortcutAddressHelp');note.textContent=location.hostname==='wordclock.local'?'Si vous êtes dans la fenêtre de connexion Wi-Fi, ouvrez cette page dans votre navigateur habituel.':'Vous utilisez actuellement une adresse IP qui peut changer. Pour un raccourci durable, essayez l’adresse locale dans Réglages > Accéder à mon horloge avant de créer le raccourci.';note.hidden=false;
  el('shortcutAdd').hidden=true;el('shortcutClose').textContent='Terminer';
 };
 el('shortcutClose').onclick=()=>shortcut.close();
 el('accessInstall').onclick=()=>{if(navigator.standalone||matchMedia('(display-mode: standalone)').matches){el('accessMessage').textContent='Vous utilisez déjà le mode application.';return;}el('shortcutAdd').hidden=false;el('shortcutHelp').hidden=true;el('shortcutAddressHelp').hidden=true;el('shortcutClose').textContent='Plus tard';if(!shortcut.open)shortcut.showModal();};
 const handoff=new URLSearchParams(location.search).get('shortcut')==='1';
 if(handoff){const u=new URL(location.href);u.searchParams.delete('shortcut');history.replaceState(null,'',u.pathname+u.search+u.hash);}

 const deviceName=el('deviceName'), deviceZone=el('deviceZone'), deviceStatus=el('deviceSummary');
 let deviceTimer=null, deviceBusy=false, devicePending={}, deviceRevision=0;
 for(const [value,label] of zones){zone.add(new Option(label,value));deviceZone.add(new Option(label,value));}
 function validName(value){return value.trim()&&new TextEncoder().encode(value.trim()).length<=48&&!/[\x00-\x1f\x7f]/.test(value);}
 function queueDevice(key,value,delay){
  deviceRevision++;devicePending[key]=value;clearTimeout(deviceTimer);deviceStatus.textContent='Enregistrement…';open.disabled=true;
  deviceTimer=setTimeout(()=>{deviceTimer=null;saveDevice();},delay);
 }
 async function saveDevice(){
  if(deviceBusy||deviceTimer!==null)return;if(!Object.keys(devicePending).length){open.disabled=false;return;}
  const changes=devicePending, revision=deviceRevision;devicePending={};deviceBusy=true;
  try{await api('/api/device',changes);await waitSaved(changes);if(revision===deviceRevision)deviceStatus.textContent='Enregistré';}
  catch(e){if(revision===deviceRevision)deviceStatus.textContent='Enregistrement non confirmé. Modifiez à nouveau le réglage pour réessayer.';}
  finally{deviceBusy=false;if(Object.keys(devicePending).length&&deviceTimer===null)saveDevice();else if(deviceTimer===null)open.disabled=false;}
 }
 deviceName.addEventListener('input',()=>{const value=deviceName.value.trim();if(!validName(deviceName.value)){deviceRevision++;delete devicePending.name;deviceStatus.textContent='Saisissez un nom valide de 48 octets maximum.';return;}queueDevice('name',value,700);});
 deviceZone.addEventListener('change',()=>queueDevice('timezone',deviceZone.value,0));
 for(const [label,value] of colors){const b=document.createElement('button');b.type='button';b.textContent=label;b.dataset.color=value;const sw=document.createElement('span');sw.className='face-swatch';sw.style.background=value;b.prepend(sw);b.onclick=()=>{color.value=value;paint();};el('setupPresets').append(b);}
 window.WordclockStudioVisual.matrixPreview(el('setupFace'));
 function paint(){const c=color.value;const rgb=[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));const light=rgb[0]*.299+rgb[1]*.587+rgb[2]*.114;el('setupFace').style.setProperty('--face-color',c);el('setupFace').style.setProperty('--face-unlit',`rgb(${rgb.map(n=>Math.round(n*.78+(light>135?0:255)*.22)).join(',')})`);for(const b of el('setupPresets').children)b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===c));}
 color.oninput=paint;
 function render(){el('setupTitle').textContent=['Bienvenue','À la bonne heure','Votre façade','Vérifier votre configuration'][step];el('setupProgress').textContent=`Étape ${step+1} sur 4`;el('setupBar').value=step+1;for(const section of dialog.querySelectorAll('[data-setup-step]'))section.hidden=Number(section.dataset.setupStep)!==step;back.hidden=step===0;next.textContent=step===3?'Enregistrer et terminer':'Continuer';skip.textContent=original&&original.setupComplete?'Annuler':'Passer la configuration';el('setupSummary').textContent=`${name.value.trim()} — ${zone.options[zone.selectedIndex].text} — ${color.value}`;}
 function lock(value){busy=value;for(const control of dialog.querySelectorAll('button,input,select'))control.disabled=value;}
 function valid(){return name.value.trim()&&new TextEncoder().encode(name.value.trim()).length<=48&&!/[\x00-\x1f\x7f]/.test(name.value);}
 async function waitSaved(expected,face){for(let i=0;i<20;i++){await sleep(1000);const d=await api('/api/device');if(d.saveFailed)throw Error('Sauvegarde non confirmée');if(!d.savePending){if(Object.keys(expected).some(k=>d[k]!==expected[k]))throw Error('Paramètres modifiés ailleurs');if(face&&(await api('/api/appearance')).faceColor.toLowerCase()!==face.toLowerCase())throw Error('Couleur non confirmée');return d;}}throw Error('Délai de sauvegarde dépassé');}
 async function finish(ignore){if(busy)return;lock(true);message.textContent='Enregistrement…';try{if(!ignore){const expected={name:name.value.trim(),timezone:zone.value};await api('/api/device',expected);await api('/api/appearance',{faceColor:color.value});await waitSaved(expected,color.value);}await api('/api/device',{setupComplete:'true'});await waitSaved({setupComplete:true});const first=!original.setupComplete;const u=new URL(location.href);if(first||handoff)u.searchParams.set("shortcut","1");location.replace(u.href);}catch(e){message.textContent='Enregistrement non confirmé. Réessayez. Des modifications peuvent déjà avoir été appliquées. ('+e.message+')';lock(false);}}
 next.onclick=()=>{if(busy)return;if(step===0&&!valid()){message.textContent='Saisissez un nom valide de 48 octets maximum.';return;}message.textContent='';if(step===3){finish(false);return;}step++;render();};
 back.onclick=()=>{if(!busy&&step>0){step--;message.textContent='';render();}};
 skip.onclick=()=>{if(busy)return;if(original.setupComplete){dialog.close();return;}finish(true);};
 dialog.addEventListener('cancel',e=>{e.preventDefault();});
 async function launch(d){const a=await api('/api/appearance');if(!/^#[0-9a-f]{6}$/i.test(a.faceColor))throw Error('Couleur invalide');original=d;name.value=d.name;zone.value=d.timezone;if(!d.setupComplete){let guess=Intl.DateTimeFormat().resolvedOptions().timeZone;if(guess==='UTC')guess='Etc/UTC';if(zones.some(z=>z[0]===guess))zone.value=guess;}color.value=a.faceColor;paint();step=0;message.textContent='';render();dialog.showModal();}
 async function refresh(auto=false){if(deviceBusy||deviceTimer!==null||Object.keys(devicePending).length||document.activeElement===deviceName)return;const revision=deviceRevision;try{const d=await api('/api/device');if(revision!==deviceRevision)return;deviceName.value=d.name;deviceZone.value=d.timezone;deviceName.disabled=false;deviceZone.disabled=false;deviceStatus.textContent='';open.disabled=false;if(auto&&!d.setupComplete)await launch(d);else if(auto&&handoff)offerShortcut();}catch(e){deviceStatus.textContent='Configuration indisponible. Réessayez.';open.disabled=false;}}
 open.onclick=async()=>{open.disabled=true;try{await launch(await api('/api/device'));}catch(e){el('deviceSummary').textContent='Configuration indisponible. Réessayez.';}finally{open.disabled=false;}};
 refresh(true);el('settingsTab').addEventListener('click',()=>refresh());
},{once:true});
})();

;
(()=>{'use strict';document.addEventListener('DOMContentLoaded',()=>{
const el=id=>document.getElementById(id), dialog=el('maintenanceDialog'),form=el('maintenanceForm'),password=el('maintenancePassword'),confirm=el('maintenanceConfirm'),msg=el('maintenanceMessage'),submit=el('maintenanceSubmit'),close=el('maintenanceClose');
let action='',busy=false,diagnostic='';
const config={info:['Informations système','État actuel de votre horloge.'],restart:['Redémarrer l’horloge','La connexion sera interrompue quelques secondes. Vos données seront conservées.'],'reset-settings':['Réinitialiser les réglages','Les couleurs, effets, luminosités, transitions et le mode nuit seront réinitialisés. Le Wi-Fi, les thèmes personnels, le nom, le fuseau horaire et la façade seront conservés.'],'factory-reset':['Restaurer les paramètres d’usine','Tous les thèmes personnels, réglages et identifiants Wi-Fi seront effacés. Exportez vos thèmes avant de continuer. Cette action est irréversible.']};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function request(path,opts={}){return window.WordclockLocal.run(async()=>{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),5000);try{const r=await fetch(path,{cache:'no-store',...opts,signal:controller.signal});if(!r.ok){const errors={401:'Mot de passe incorrect.',403:'Action refusée.',409:'Horloge occupée ou sauvegarde en attente. Réessayez dans quelques secondes.',503:'Stockage indisponible ou opération non confirmée.'};throw new Error(errors[r.status]||`Erreur HTTP ${r.status}`);}return await r.json();}finally{clearTimeout(timer);}});}
function lock(v){busy=v;for(const c of dialog.querySelectorAll('button,input'))c.disabled=v;}
function info(){return request('/api/system');}
const kib=n=>Number.isFinite(n)?`${(n/1024).toFixed(1)} Kio`:'Indisponible';
async function refresh(){lock(true);diagnostic='';msg.textContent='Chargement…';try{const d=await info();const rows=[['Firmware',d.firmware],['Adresse locale',d.hostname],['Adresse IP',d.ip],['Signal Wi-Fi',`${d.rssi} dBm`],['Fonctionnement',`${d.uptime} s`],['RAM libre',kib(d.freeHeap)],['Flash',kib(d.flashBytes)],['Stockage',d.storageReady?'Opérationnel':'Indisponible'],['Stockage utilisé',`${kib(d.storageUsed)} / ${kib(d.storageTotal)}`],['Sauvegarde',d.saveFailed?'Erreur':d.savePending?'En attente':'Terminée']];const dl=el('maintenanceValues');dl.replaceChildren();for(const [k,v] of rows){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=v;dl.append(dt,dd);}diagnostic=rows.map(r=>r.join(': ')).join('\n');const bar=el('maintenanceStorage');bar.hidden=!(d.storageTotal>0&&Number.isFinite(d.storageUsed));bar.value=bar.hidden?0:100*d.storageUsed/d.storageTotal;msg.textContent='';}catch(e){msg.textContent=e.message;}finally{lock(false);}}
for(const b of document.querySelectorAll('[data-maintenance]'))b.onclick=()=>{if(busy)return;action=b.dataset.maintenance;const c=config[action];el('maintenanceTitle').textContent=c[0];el('maintenanceDescription').textContent=c[1];msg.textContent='';password.value='';confirm.value='';form.hidden=action==='info';el('maintenanceInfo').hidden=action!=='info';el('maintenanceConfirmWrap').hidden=action!=='factory-reset';confirm.required=action==='factory-reset';submit.textContent=action==='factory-reset'?'Tout effacer':'Confirmer';submit.classList.toggle('danger',action==='factory-reset');dialog.showModal();if(action==='info')refresh();};
close.onclick=()=>{if(!busy){password.value='';dialog.close();}};dialog.addEventListener('cancel',e=>{e.preventDefault();close.click();});el('maintenanceRefresh').onclick=refresh;
el('maintenanceCopy').onclick=async()=>{if(!diagnostic)return;try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(diagnostic);else{const t=document.createElement('textarea');t.value=diagnostic;dialog.append(t);t.select();let ok=false;try{ok=document.execCommand('copy');}finally{t.remove();}if(!ok)throw Error();}msg.textContent='Diagnostic copié.';}catch{msg.textContent='Copie automatique indisponible. Sélectionnez les informations affichées.';}};
form.onsubmit=async e=>{e.preventDefault();if(busy)return;if(action==='factory-reset'&&confirm.value!=='EFFACER'){msg.textContent='Saisissez exactement EFFACER.';return;}lock(true);msg.textContent='Envoi de la demande…';let accepted=false;try{const auth=btoa(Array.from(new TextEncoder().encode('admin:'+password.value),b=>String.fromCharCode(b)).join(''));password.value='';const d=await request('/api/system/'+action,{method:'POST',headers:{Authorization:'Basic '+auth,'X-Wordclock-Action':action,'Content-Type':'application/x-www-form-urlencoded'},body:action==='factory-reset'?'confirm=ERASE':''});if(!d.ok)throw Error('Demande non confirmée.');accepted=true;form.hidden=true;if(action==='factory-reset'){msg.textContent='Restauration acceptée. Attendez le redémarrage, puis connectez-vous à Wordclock-Setup (mot de passe Wordclock123). Ouvrez http://192.168.4.1 si nécessaire. La fin de la restauration sera confirmée lors de la nouvelle installation.';return;}if(action==='reset-settings'){for(let i=0;i<20;i++){await sleep(1000);const state=await info();if(state.saveFailed)throw Error('Échec de sauvegarde.');if(!state.savePending){location.reload();return;}}throw Error('Délai de sauvegarde dépassé.');}msg.textContent='Redémarrage accepté. Attente de la reconnexion…';await sleep(5000);for(let i=0;i<15;i++){try{const state=await info();if(!state.restartPending){location.reload();return;}}catch{}await sleep(1500);}throw Error('Reconnexion non confirmée. Essayez wordclock.local.');}catch(e){msg.textContent=(accepted?'Opération acceptée, mais résultat final non confirmé. ':'Demande non confirmée. Vérifiez l’état de l’horloge avant de réessayer. ')+e.message;}finally{password.value='';lock(false);}};
},{once:true});})();

// Update client: no additional embedded asset or external executable dependency.
(()=>{'use strict';
const BASE='https://ccachin.github.io/Wordclock-2.0/';
const names='index.html style.css app.js night.js studio.js theme-rules.js studio-visual.js community.js setup.js maintenance.js icon.svg manifest.json'.split(' ');
const decoder=new TextDecoder('utf-8',{fatal:true});
const version=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-dev(?:\.(0|[1-9]\d*))?)?$/;
function cmp(a,b){const x=version.exec(a),y=version.exec(b);if(!x||!y)throw Error('Version invalide');for(let i=1;i<=3;i++){const d=Number(x[i])-Number(y[i]);if(d)return Math.sign(d);}return a.includes('-dev')===b.includes('-dev')?Math.sign(Number(x[4]||0)-Number(y[4]||0)):a.includes('-dev')?-1:1;}
// SHA-256 fallback for the local HTTP origin, where SubtleCrypto is unavailable.
async function sha(bytes){if(globalThis.crypto?.subtle)return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
const k=[],h=[];for(let n=2;k.length<64;n++){let prime=true;for(let d=2;d*d<=n;d++)if(n%d===0){prime=false;break;}if(prime){if(h.length<8)h.push((Math.sqrt(n)%1*4294967296)|0);k.push((Math.cbrt(n)%1*4294967296)|0);}}
const p=new Uint8Array(Math.ceil((bytes.length+9)/64)*64);p.set(bytes);p[bytes.length]=128;const dv=new DataView(p.buffer);dv.setUint32(p.length-4,bytes.length*8);const w=new Int32Array(64),r=(x,n)=>(x>>>n)|(x<<(32-n));for(let o=0;o<p.length;o+=64){for(let i=0;i<16;i++)w[i]=dv.getInt32(o+i*4);for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(r(a,7)^r(a,18)^(a>>>3))+w[i-7]+(r(b,17)^r(b,19)^(b>>>10)))|0;}let [a,b,c,d,e,f,g,j]=h;for(let i=0;i<64;i++){const t=(j+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+k[i]+w[i])|0,u=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0;j=g;g=f;f=e;e=(d+t)|0;d=c;c=b;b=a;a=(t+u)|0;}[a,b,c,d,e,f,g,j].forEach((v,i)=>h[i]=(h[i]+v)|0);}return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');}
async function bytes(url,max){const r=await fetch(url,{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('HTTP '+r.status);const reader=r.body.getReader(),parts=[];let size=0;try{while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Fichier trop volumineux');parts.push(value);}}finally{await reader.cancel().catch(()=>{});}const out=new Uint8Array(size);let i=0;for(const p of parts){out.set(p,i);i+=p.length;}return out;}
const parse=b=>JSON.parse(decoder.decode(b));
async function checked(url,d,max){if(!d||!Number.isSafeInteger(d.size)||d.size<1||d.size>max||! /^[a-f0-9]{64}$/.test(d.sha256))throw Error('Descripteur invalide');const b=await bytes(url,d.size);if(b.length!==d.size||await sha(b)!==d.sha256)throw Error('Empreinte incorrecte');return b;}
async function unzip(b,m){const v=new DataView(b.buffer,b.byteOffset,b.byteLength),files=new Map();let o=0;while(o+4<=b.length&&v.getUint32(o,true)===0x04034b50){if(o+30>b.length)throw Error('ZIP tronqué');const flags=v.getUint16(o+6,true),method=v.getUint16(o+8,true),compressed=v.getUint32(o+18,true),size=v.getUint32(o+22,true),nl=v.getUint16(o+26,true),xl=v.getUint16(o+28,true),start=o+30+nl+xl;if(flags&~0x800||start+compressed>b.length)throw Error('ZIP non pris en charge');const name=decoder.decode(b.subarray(o+30,o+30+nl)),item=m.files.find(f=>f.path===name);if(!item||files.has(name)||size!==item.size)throw Error('Entrée ZIP invalide');let data=b.subarray(start,start+compressed);if(method===8){if(!globalThis.DecompressionStream)throw Error('Navigateur incompatible avec ZIP');const reader=new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();const out=new Uint8Array(size);let pos=0;try{while(true){const {done,value}=await reader.read();if(done)break;if(pos+value.length>size)throw Error('ZIP trop volumineux');out.set(value,pos);pos+=value.length;}}finally{await reader.cancel().catch(()=>{});}data=out;if(pos!==size)throw Error('ZIP incomplet');}else if(method!==0)throw Error('Compression inconnue');if(data.length!==size||await sha(data)!==item.sha256)throw Error('Ressource invalide : '+name);files.set(name,data);o=start+compressed;}if(files.size!==names.length||o+4>b.length||v.getUint32(o,true)!==0x02014b50)throw Error('ZIP incomplet');return files;}
function validate(m,rel){if(m.format!=='wordclock-web'||m.manifestVersion!==1||m.version!==rel.webVersion||m.compatibility?.webApiVersion!==1||m.fileCount!==12||!Array.isArray(m.files)||m.files.length!==12||new Set(m.files.map(f=>f.path)).size!==12||m.files.some(f=>!names.includes(f.path)||!Number.isSafeInteger(f.size)||f.size<1||f.size>131072||! /^[a-f0-9]{64}$/.test(f.sha256))||m.totalBytes!==m.files.reduce((s,f)=>s+f.size,0)||m.totalBytes>393216)throw Error('Manifeste web invalide');}
document.addEventListener('DOMContentLoaded',()=>{const $=id=>document.getElementById(id),panel=$('updatesPanel');if(!panel)return;const status=$('updateStatus'),progress=$('updateProgress'),install=$('updateInstall'),channel=$('updateChannel'),notes=$('updateNotes');let busy=false,candidate=null;channel.value='development';
function lock(v){busy=v;window.WordclockLocal.setBusy(v);for(const e of panel.querySelectorAll('button,input,select'))e.disabled=v;}
function message(s){status.textContent=s;}function bar(n){progress.hidden=false;progress.value=n;}
async function local(path,options={}){return window.WordclockLocal.run(async()=>{const r=await fetch(path,{cache:'no-store',...options,signal:AbortSignal.timeout(30000)});const d=await r.json();if(!r.ok)throw Error(`HTTP ${r.status} : ${d.error||'action refusée'}`);return d;},true);}
const system=()=>local('/api/system');function auth(){const p=prompt('Mot de passe administrateur (réseau local)');return p===null?null:'Basic '+btoa(Array.from(new TextEncoder().encode('admin:'+p),x=>String.fromCharCode(x)).join(''));}
function api(a,action,path,method='POST',body){return local('/api/system/'+path,{method,headers:{Authorization:a,'X-Wordclock-Action':action,...(body instanceof Uint8Array?{'Content-Type':'text/plain'}:{})},body});}
async function check(){if(busy)return;lock(true);candidate=null;$('updateAvailable').textContent='';install.hidden=true;notes.hidden=true;progress.hidden=true;message('Recherche…');try{
const d=await system();$('updateInstalled').textContent=`Firmware : ${d.firmware} · Interface : ${d.webVersion||'développement / inconnue'}`;
const c=parse(await bytes(BASE+'catalog.json',32768));if(c.format!=='wordclock-release-catalog'||c.version!==1||!Array.isArray(c.releases))throw Error('Catalogue invalide');
const entries=c.releases.filter(e=>e.channel===channel.value&&version.test(e.version)&&e.manifest===`releases/${e.version}/release.json`).sort((a,b)=>cmp(b.version,a.version));
let web=null,fw=null;for(const e of entries){const raw=await bytes(BASE+e.manifest,8192);if(await sha(raw)!==e.sha256)throw Error('Empreinte du manifeste incorrecte');const r=parse(raw),root=BASE+`releases/${e.version}/`;
if(r.format!=='wordclock-release'||r.manifestVersion!==1||r.version!==e.version||r.channel!==channel.value)throw Error('Publication invalide');if(r.compatibility?.board!=='d1'||r.compatibility?.webApiVersion!==d.webApiVersion)continue;
if(!/^\d+\.\d+\.\d+$/.test(r.webVersion)||r.artifacts?.web?.path!=='web.zip'||r.artifacts?.webManifest?.path!=='web-manifest.json'||r.artifacts?.notes?.path!=='CHANGELOG.md')throw Error('Publication invalide');
if(!web||cmp(r.webVersion,web.r.webVersion)>0)web={r,root};if(r.firmwareVersion!=null){if(!version.test(r.firmwareVersion)||r.artifacts.firmware?.path!=='firmware.bin'||r.artifacts.firmwareSignature?.path!=='firmware.sig')throw Error('Firmware invalide');if(!fw||cmp(r.firmwareVersion,fw.r.firmwareVersion)>0)fw={r,root};}}
if(!web){message('Aucune publication compatible sur ce canal.');return;}
$('updateAvailable').textContent=`Disponibles — Firmware : ${fw?.r.firmwareVersion||'aucun'} · Interface : ${web.r.webVersion}`;
const body=$('updateNotesBody');body.replaceChildren();for(const item of [web,...(fw&&fw.r.version!==web.r.version?[fw]:[])]){const heading=document.createElement('h4');heading.textContent=item.r.version;body.append(heading);const text=decoder.decode(await checked(item.root+'CHANGELOG.md',item.r.artifacts.notes,32768));const pre=document.createElement('p');pre.style.whiteSpace='pre-wrap';pre.textContent=text;body.append(pre);}
$('updateNotesTitle').textContent='Notes de publication';notes.open=false;notes.hidden=false;
const w=!d.webVersion||cmp(web.r.webVersion,d.webVersion)>0||(d.webVersionState!=='manifest'&&cmp(web.r.webVersion,d.webVersion)>=0);const f=fw&&cmp(fw.r.firmwareVersion,d.firmware)>0;candidate={web:w?web:null,fw:f?fw:null};install.hidden=!(w||f);message(w||f?'Une mise à jour est disponible.':'Aucune version plus récente sur ce canal.');}catch(e){message('Recherche impossible : '+e.message);}finally{lock(false);}}
async function webTransfer(a,raw,m,files){let id=null,activating=false;try{const form=new FormData();form.append('manifest',new Blob([raw],{type:'application/json'}),'web-manifest.json');const req=(path,method='POST',body)=>api(a,'web-update','web-update/'+path,method,body);const before=await system();const start=await req('start','POST',form);id=start.id;if(!Number.isSafeInteger(id)||id<=0)throw Error('Session invalide');let sent=0;for(const [name,data] of files){for(let offset=0;offset<data.length;offset+=512){const chunk=data.subarray(offset,offset+512),q=new URLSearchParams({id,name,offset});const result=await req('chunk?'+q,'PUT',chunk);if(result.offset!==offset+chunk.length)throw Error('Décalage incorrect');sent+=chunk.length;bar(95*sent/m.totalBytes);message('Transfert : '+Math.floor(100*sent/m.totalBytes)+' %');}}message('Vérification sur l’horloge…');const verified=await req('verify?id='+id);if(!verified.verified||verified.verifiedFiles!==12)throw Error('Vérification non confirmée');activating=true;const switched=await req('activate?id='+id+'&confirm=SWITCH');if(!switched.activated)throw Error('Activation non confirmée');id=null;const after=await system();if(after.webSlot===before.webSlot||after.webSlotGeneration!==switched.generation||after.webVersion!==m.version||after.webVersionState!=='manifest')throw Error('Version finale non confirmée');bar(100);message('Interface installée.'); }catch(e){if(id!==null&&!activating){try{await api(a,'web-update','web-update/cancel?id='+id);}catch{}}throw e;}}
async function transfer(){if(busy||!candidate)return;const {web,fw}=candidate;if(!web&&!fw)return;if(!confirm('Installer '+[fw&&'le firmware '+fw.r.firmwareVersion,web&&'l’interface '+web.r.webVersion].filter(Boolean).join(' puis ')+' ?'))return;const a=auth();if(!a)return;lock(true);try{message('Téléchargement et vérification…');bar(0);let data,sig,raw,m,files;if(fw){data=await checked(fw.root+'firmware.bin',fw.r.artifacts.firmware,1044464);sig=await checked(fw.root+'firmware.sig',fw.r.artifacts.firmwareSignature,256);}if(web){raw=await checked(web.root+'web-manifest.json',web.r.artifacts.webManifest,4096);m=parse(raw);validate(m,web.r);files=await unzip(await checked(web.root+'web.zip',web.r.artifacts.web,393216),m);}if(fw)await firmwareTransfer(a,data,sig,fw.r.firmwareVersion);if(web)await webTransfer(a,raw,m,files);message('Mise à jour confirmée. Rechargement…');setTimeout(()=>location.replace('/?updated='+Date.now()),800);}catch(e){message('Mise à jour interrompue ou résultat à vérifier : '+e.message);}finally{candidate=null;install.hidden=true;lock(false);}}
async function rollback(){if(busy||!confirm('Restaurer l’interface précédente ?'))return;const a=auth();if(!a)return;lock(true);try{const d=await api(a,'web-update','web-update/rollback?confirm=SWITCH');if(!d.activated)throw Error('Restauration non confirmée');const s=await system();if(s.webSlot!==d.webSlot||s.webSlotGeneration!==d.generation)throw Error('État final non confirmé');location.replace('/?updated='+Date.now());}catch(e){message(e.message);}finally{lock(false);}}
async function firmwareTransfer(a,data,sig,target){let token=null,activating=false;const req=(path,method='POST',body)=>api(a,'firmware-update','firmware/'+path,method,body);try{if(data[0]!==233||data.length<12288||data.length>1044464||sig.length!==256)throw Error('Image ou signature invalide');const h=await sha(data),before=await system(),signature=Array.from(sig,v=>v.toString(16).padStart(2,'0')).join('');const pre=await api(a,'firmware-update','firmware','GET');if(pre.protocol!==2||!pre.ready)throw Error('Protocole firmware indisponible');let ticket;for(let i=0;i<12;i++){try{ticket=await req('authorize?'+new URLSearchParams({size:data.length,sha256:h,confirm:'INSTALL',signature}));break;}catch(e){if(i===11||!e.message.includes('HTTP 503')||!e.message.includes('Insufficient verification memory'))throw e;message('Préparation du firmware : mémoire temporairement indisponible…');await new Promise(r=>setTimeout(r,5000));}}
if(!/^[0-9a-f]{32}$/.test(ticket.token))throw Error('Autorisation invalide');const session=await req('start?'+new URLSearchParams({token:ticket.token,confirm:'INSTALL'}));token=session.token;if(!/^[0-9a-f]{32}$/.test(token)||![512,1024].includes(session.chunkSize)||session.offset!==0)throw Error('Session invalide');for(let offset=0;offset<data.length;offset+=session.chunkSize){const block=data.subarray(offset,offset+session.chunkSize),r=await req('chunk?'+new URLSearchParams({token,offset}),'PUT',block);if(r.offset!==offset+block.length)throw Error('Décalage invalide');bar(95*r.offset/data.length);message('Firmware : '+Math.floor(100*r.offset/data.length)+' %');}const v=await req('verify?token='+token);if(!v.verified)throw Error('Intégrité non confirmée');activating=true;const d=await req('activate?token='+token+'&confirm=INSTALL');if(!d.installationScheduled||!d.sha256Verified)throw Error('Activation non confirmée');message('Redémarrage attendu…');for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,5000));try{const state=await system();if(state.buildId!==before.buildId&&state.sketchBytes===data.length&&(!target||state.firmware===target)){bar(100);message('Nouveau firmware confirmé.');return;}}catch{}}throw Error('Nouveau firmware non confirmé');}catch(e){if(token&&!activating){try{await req('cancel?token='+token);}catch{}}throw e;}}
async function firmware(){const f=$('updateFirmware').files[0],sf=$('updateSignature').files[0];if(busy||!f||!sf)return;if(sf.size!==256||f.size<12288||f.size>1044464){message('Firmware ou signature invalide.');return;}if(!confirm('Installer ce firmware signé ? L’horloge redémarrera.'))return;const a=auth();if(!a)return;lock(true);try{await firmwareTransfer(a,new Uint8Array(await f.arrayBuffer()),new Uint8Array(await sf.arrayBuffer()),null);}catch(e){message('Installation interrompue ou résultat à vérifier : '+e.message);}finally{lock(false);$('updateFirmware').value='';$('updateSignature').value='';}}
$('updateCheck').onclick=check;channel.onchange=check;install.onclick=transfer;$('updateRollback').onclick=rollback;$('updateManual').onclick=firmware;message('Recherchez les mises à jour disponibles.');window.WordclockLocal.run(async()=>{const r=await fetch('/api/system',{cache:'no-store',signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('HTTP '+r.status);const d=await r.json();$('updateInstalled').textContent=`Firmware : ${d.firmware} · Interface : ${d.webVersion||'développement / inconnue'}`;}).catch(()=>{});
},{once:true});})();
