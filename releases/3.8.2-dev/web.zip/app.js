const animationControls = Object.fromEntries(["front","rear"].map(face =>[face,{
effect:document.getElementById(face + "Effect"),
speed:document.getElementById(face + "Speed"),
row:document.getElementById(face + "SpeedRow"),
value:document.getElementById(face + "SpeedValue")
}]));
function updateAnimationControls(){
for(const c of Object.values(animationControls)){
c.row.hidden = c.effect.value === "solid";
c.value.textContent = c.speed.value + " %";
}
}
const timeElement =
document.getElementById("time");
const statusElement =
document.getElementById("status");
const frontColor =
document.getElementById("frontColor");
const rearColor =
document.getElementById("rearColor");
const brightness =
document.getElementById("brightness");
const brightnessValue =
document.getElementById("brightnessValue");
const harmony =
document.getElementById("harmony");
const harmonyDescription =
document.getElementById("harmonyDescription");
const manualRearRow =
document.getElementById("manualRearRow");
const automaticRearRow =
document.getElementById("automaticRearRow");
const effectiveRearColor =
document.getElementById("effectiveRearColor");
const frontPreview =
document.getElementById("frontPreview");
const rearPreview =
document.getElementById("rearPreview");
const themeList =
document.getElementById("themeList");
const activeTheme =
document.getElementById("activeTheme");
const message =
document.getElementById("message");
let themes =[];
let activePreset=-1,savedTheme=null,themeDraft=false;
const ambEl=id=>document.getElementById(id);
const transitionNames=["Aucune","Fondu","Balayage","Matrix","Apparition","Explosion","Coucou","Dissolution","Vague diagonale","Scanner","Étincelles","Onde circulaire"];
function decodeBehavior(n){return{enabled:!!(n&1),hourlyColor:!!(n&2),transition:((n>>>2)&7)|(((n>>>29)&1)<<3),chime:(n>>>5)&3,spatial:(n>>>7)&3,intensity:(n>>>9)&127,duration:((n>>>16)&63)*100,spatialSpeed:(n>>>22)&127};}
function frontStyle(t){const b=decodeBehavior(t.frontBehavior);return{effect:!b.enabled?"solid":b.spatial===1?"rainbow":b.spatial===2?"chase":t.frontEffect,speed:b.spatial?b.spatialSpeed:t.frontSpeed};}
let themeTimer = null;
let pending = false;
let currentRequest = null;
let applyingTheme = false;
let initialized = false;
let revision = 0;
let effectiveRear = "#3c64b4";
const harmonyDescriptions ={
"manual":
"Deux couleurs entièrement indépendantes.",
"identical":
"La même couleur à l'avant et à l'arrière.",
"complementary":
"Une couleur opposée sur le cercle chromatique.",
"analogous-plus":
"Une couleur voisine, décalée de +30°.",
"analogous-minus":
"Une couleur voisine, décalée de -30°.",
"triadic":
"Une couleur décalée de 120°."
};
window.WordclockLocal =(()=>{
let tail = Promise.resolve(),maintenance = false;
return{
get busy(){return maintenance;},
setBusy(value){maintenance = value;},
run(task,privileged=false){
const next = tail.then(()=>{
if(maintenance && !privileged)throw Error('Mise à jour en cours');
return task();
});
tail = next.catch(()=>{});
return next;
}
};
})();
async function request(url,options ={}){
return window.WordclockLocal.run(async()=>{
const response = await fetch(url,{
cache:"no-store",
signal:AbortSignal.timeout(10000),
...options
});
if(!response.ok){
throw new Error(
"HTTP " + response.status
);
}
return await response.json();
});
}
async function confirmStored(element,label){
const waiting=label+' — enregistrement en cours…';
element.textContent=waiting;
for(let i=0;i<6;i++){
await new Promise(resolve=>setTimeout(resolve,700));
if(element.textContent!==waiting)return;
try{
const state=await request('/api/system');
if(element.textContent!==waiting)return;
if(state.saveFailed){element.textContent=label+' — sauvegarde en échec.';return;}
if(!state.savePending){element.textContent=label+' — enregistré.';return;}
}catch(e){}
}
if(element.textContent===waiting)element.textContent=label+' — sauvegarde non confirmée.';
}
function showMessage(text,error = false){
message.textContent = text;
message.classList.toggle(
"error",
error
);
}
let clockAnchor = null;
function tickLocalClock(){
if(!clockAnchor)return;
const sec=(clockAnchor.seconds+Math.floor((performance.now()-clockAnchor.at)/1000))%86400;
const h=Math.floor(sec/3600),m=Math.floor(sec/60)%60;
timeElement.textContent=[h,m,sec%60].map(n=>String(n).padStart(2,'0')).join(':');
}
setInterval(tickLocalClock,1000);
async function updateStatus(){
if(window.WordclockLocal.busy || document.hidden){setTimeout(updateStatus,5000);return;}
try{
const data =
await request("/api/status");
timeElement.textContent =
data.timeValid
? data.time
:"--:--:--";
const full=data.timeValid&&/^(\d{2}):(\d{2}):(\d{2})$/.exec(data.time);
clockAnchor=full?{seconds:Number(full[1])*3600+Number(full[2])*60+Number(full[3]),at:performance.now()}:null;
statusElement.textContent =
"Connectée";
statusElement.style.color =
"var(--success)";
}catch(error){
statusElement.textContent =
"Connexion perdue";
statusElement.style.color =
"var(--error)";
clockAnchor=null;
timeElement.textContent =
"--:--:--";
}finally{
setTimeout(updateStatus,5000);
}
}
let frontBrightness = 100;
let rearBrightness = 100;
const faceBrightnessHome ={front:document.getElementById('frontBrightnessHome'),rear:document.getElementById('rearBrightnessHome')};
function updateFaceBrightnessLabels(){
for(const[face,value]of Object.entries({front:frontBrightness,rear:rearBrightness})){
faceBrightnessHome[face].value=value;
document.getElementById(face+'BrightnessHomeValue').textContent=value+' %';
}
}
function setControlsEnabled(enabled){
document.getElementById("powerToggle").disabled = !enabled;
frontColor.disabled = !enabled;
rearColor.disabled = !enabled;
brightness.disabled = !enabled;
for(const control of Object.values(faceBrightnessHome))control.disabled=!enabled;
harmony.disabled = !enabled;
for(const c of Object.values(animationControls)){c.effect.disabled = !enabled;c.speed.disabled = !enabled;}
ambEl("effectsFields").disabled=!enabled;
ambEl("transitionEnabled").disabled=!enabled;
ambEl("transitionDuration").disabled=!enabled||!ambEl("transitionEnabled").checked;
ambEl("effectsSave").disabled=!enabled||!themeDraft;
ambEl("effectsCancel").disabled=!enabled||!themeDraft;
ambEl("themeReset").disabled=!enabled||(!themeDraft&&!themes.find(t=>t.index===activePreset)?.modified);
ambEl("themeResetAll").disabled=!enabled;
ambEl("effectsTest").disabled=!enabled||themeDraft;
themeList.querySelectorAll(".theme-card,.ambience-edit").forEach(button=>button.disabled=!enabled);
}
function updateBrightnessLabel(){
updateFaceBrightnessLabels();
document.getElementById("powerToggle").textContent=Number(brightness.value)===0?"Allumer":"Éteindre";
if(Number(brightness.value)>0){lastBrightness=Number(brightness.value);try{localStorage.setItem("wordclock-last-brightness",String(lastBrightness));}catch(e){}}
brightnessValue.textContent =
Math.round(
Number(brightness.value)/ 255 * 100
)+ " %";
}
function readableTextColor(hex){
const rgb = parseInt(
hex.replace("#",""),
16
);
const r =(rgb >> 16)& 255;
const g =(rgb >> 8)& 255;
const b = rgb & 255;
const luminance =
(r * 299 + g * 587 + b * 114)/ 1000;
return luminance > 155
? "#000000"
:"#ffffff";
}
function setPreviewColor(element,color){
element.style.backgroundColor = color;
element.style.color =
readableTextColor(color);
}
function updatePalettePreview(){
const rear = harmony.value === "manual"
? rearColor.value
:effectiveRear;
setPreviewColor(
frontPreview,
frontColor.value
);
setPreviewColor(
rearPreview,
rear
);
effectiveRearColor.style.backgroundColor =
rear;
effectiveRearColor.title =
rear.toUpperCase();
}
function updateHarmonyControls(){
const manual =
harmony.value === "manual";
manualRearRow.hidden = !manual;
automaticRearRow.hidden = manual;
harmonyDescription.textContent =
harmonyDescriptions[harmony.value]|| "";
updatePalettePreview();
}
function updateControls(data){
savedTheme={...data};activePreset=data.preset;
if(!themeDraft){
const b=decodeBehavior(data.frontBehavior);
for(const[face,c]of Object.entries(animationControls)){
c.effect.value=face==='front'&&b.spatial?b.spatial===1?'rainbow':'chase':data[face+'Effect']||'solid';
c.speed.value=face==='front'&&b.spatial?b.spatialSpeed:data[face+'Speed']??50;
}
frontColor.value=data.front.toLowerCase();rearColor.value=data.rear.toLowerCase();harmony.value=data.harmony||'manual';
effectiveRear=(data.effectiveRear||data.rear).toLowerCase();
ambEl('effectsEnabled').checked=b.enabled;ambEl('effectsHourly').checked=b.hourlyColor;
for(const k of['transition','chime','duration','intensity'])ambEl('effects'+k[0].toUpperCase()+k.slice(1)).value=b[k];
ambEl('transitionEnabled').checked=data.fadeDuration>0;
if(data.fadeDuration>0)ambEl('transitionDuration').value=data.fadeDuration;
updateAnimationControls();updateAmbienceLabels();updateHarmonyControls();
}
brightness.value=data.brightness;frontBrightness=data.frontBrightness??100;rearBrightness=data.rearBrightness??100;
updateBrightnessLabel();updateActiveTheme();
}
function updateActiveTheme(){
const selected=themes.find(t=>t.index===activePreset);
activeTheme.textContent=selected?.name||'Chargement…';
ambEl('homeTheme').textContent=activeTheme.textContent;
ambEl('themeEditorTitle').textContent=selected?'Personnaliser '+selected.name:'Personnaliser le thème choisi';
themeList.querySelectorAll('.theme-card').forEach(button=>{
const t=themes.find(x=>x.id===button.dataset.id),active=!!selected&&selected.id===button.dataset.id;
button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
button.querySelector('.theme-state').textContent=(active?'Thème choisi':'Choisir')+(t?.modified?' · Personnalisé':'');
button.parentElement.querySelector('.ambience-edit').hidden=!active;
});
}
function renderThemeLibrary(){
themeList.replaceChildren();
for(const theme of themes){
const button =
document.createElement("button");
button.type = "button";
button.className = "theme-card";
button.dataset.id = theme.id;
const preview =
document.createElement("div");
preview.className = "theme-preview";
const v = window.WordclockStudioVisual;
const f = v.rgb(theme.front);
const offsets ={identical:0,complementary:180,'analogous-plus':30,'analogous-minus':-30,triadic:120};
const r = theme.harmony && theme.harmony !== 'manual' ? v.rotate(f,offsets[theme.harmony]?? 0):v.rgb(theme.rear);
const behavior=decodeBehavior(theme.frontBehavior),front=frontStyle(theme),rear=behavior.enabled?theme.rearEffect:'solid';
const sample=document.createElement('div');sample.className='theme-animation-samples';
const halo=document.createElement('div');halo.className='theme-halo-preview';
const pixels=v.rearSample(halo);
v.animateSample(halo,r,rear,theme.rearSpeed,pixels,20);
v.matrixPreview(preview,8,25);
v.animateSample(preview,f,front.effect,front.speed,[...preview.querySelectorAll('text')].map((node,i)=>({node,i})).filter(p=>p.node.classList.contains('lit')),121);
sample.append(halo,preview);
const effectLabel=document.createElement('span');effectLabel.className='theme-effect-label';
effectLabel.textContent=behavior.enabled?[behavior.transition?transitionNames[behavior.transition]:'',behavior.chime?'Signal horaire':'',behavior.hourlyColor?'Couleur horaire':''].filter(Boolean).join(' · '):'Animations désactivées';
const description=document.createElement('span');description.className='theme-description';description.textContent=theme.description||'';
const name =
document.createElement("span");
name.className = "theme-name";
name.textContent = theme.name;
const colors =
document.createElement("div");
colors.className = "theme-colors";
for(const color of[
theme.front,
theme.rear
]){
const dot =
document.createElement("span");
dot.className = "color-dot";
dot.style.backgroundColor = color;
colors.appendChild(dot);
}
button.append(
sample,
name,
colors,description,effectLabel
);
const state=document.createElement("span");state.className="theme-state";button.append(state);
button.addEventListener(
"click",
()=> applyTheme(theme.id)
);
const tile=document.createElement('div');tile.className='library-tile';
const edit=document.createElement('button');edit.type='button';edit.className='action-button ambience-edit';edit.textContent='Personnaliser';edit.hidden=true;edit.addEventListener('click',()=>{ambEl('themeEditor').open=true;ambEl('themeEditor').scrollIntoView({block:'start'});});
tile.append(button,edit);themeList.appendChild(tile);
}
updateActiveTheme();
setControlsEnabled(
initialized && !applyingTheme
);
}
async function initialize(){
if(window.WordclockLocal.busy){setTimeout(initialize,3000);return;}
setControlsEnabled(false);
try{
const data =
await request("/api/theme");
if(!data.harmony || !data.frontEffect || !data.rearEffect || !Number.isInteger(data.preset)|| !Number.isInteger(data.frontBehavior)){
throw new Error(
"Firmware update required"
);
}
updateControls(data);
themes =
await request("/api/themes?version=3&factoryOnly=1");
initialized = true;
renderThemeLibrary();
setControlsEnabled(true);
showMessage("");
}catch(error){
showMessage(
"Impossible de charger les réglages. Nouvelle tentative en cours…",
true
);
setTimeout(initialize,3000);
}
}
function sendTheme(){
if(!initialized || applyingTheme){
return;
}
if(currentRequest){
pending = true;
return;
}
pending = false;
const requestRevision = revision;
const params = new URLSearchParams({brightness:brightness.value,frontBrightness,rearBrightness});
currentRequest = request(
"/api/theme",
{
method:"POST",
body:params
}
)
.then(data =>{
if(
requestRevision === revision &&
!applyingTheme
){
updateControls(data);
showMessage("Réglages modifiés");void confirmStored(message,"Réglages modifiés");
}
})
.catch(error =>{
if(requestRevision === revision){
showMessage(
"Impossible d'appliquer les réglages.",
true
);
}
})
.finally(()=>{
currentRequest = null;
if(pending && !applyingTheme){
sendTheme();
}
});
}
function scheduleThemeUpdate(){
revision++;
showMessage("Modification en cours…");
updateAnimationControls();
updateBrightnessLabel();
updateHarmonyControls();
clearTimeout(themeTimer);
themeTimer = setTimeout(
sendTheme,
100
);
}
async function applyTheme(id){
if(applyingTheme || !initialized){
return false;
}
if(themeDraft&&!confirm("Abandonner les modifications non enregistrées ?"))return false;
themeDraft=false;
applyingTheme = true;
revision++;
clearTimeout(themeTimer);
pending = false;
setControlsEnabled(false);
if(currentRequest){
await currentRequest;
}
try{
await request(
"/api/theme",
{
method:"POST",
body:new URLSearchParams({
brightness:brightness.value,frontBrightness,rearBrightness
})
}
);
const levels={frontBrightness,rearBrightness};
let data = await request(
"/api/themes/apply",
{
method:"POST",
body:new URLSearchParams({
id
})
}
);
if(data.frontBrightness!==levels.frontBrightness||data.rearBrightness!==levels.rearBrightness){
data=await request('/api/theme',{method:'POST',body:new URLSearchParams(levels)});
}
updateControls(data);
ambEl('effectsMessage').textContent='';
ambEl("themeLibraryMessage").textContent="Thème choisi : "+(themes.find(t=>t.index===activePreset)?.name||"");
showMessage("Thème appliqué");void confirmStored(message,"Thème appliqué");
return true;
}catch(error){
ambEl("themeLibraryMessage").textContent="Impossible de choisir ce thème. Réessayez.";
showMessage(
"Impossible d'appliquer le thème.",
true
);
try{
const data =
await request("/api/theme");
updateControls(data);
}catch(syncError){
console.error(syncError);
}
return false;
}finally{
applyingTheme = false;
setControlsEnabled(true);
}
}
frontColor.addEventListener(
"input",
markThemeDraft
);
rearColor.addEventListener(
"input",
markThemeDraft
);
brightness.addEventListener(
"input",
scheduleThemeUpdate
);
for(const[face,control]of Object.entries(faceBrightnessHome))control.addEventListener('input',()=>{
if(face==='front')frontBrightness=Number(control.value);else rearBrightness=Number(control.value);
scheduleThemeUpdate();
});
harmony.addEventListener(
"change",
markThemeDraft
);
let lastBrightness=8;
try{const n=Number(localStorage.getItem('wordclock-last-brightness'));if(Number.isInteger(n)&&n>0&&n<=255)lastBrightness=n;}catch(e){}
const powerToggle=document.getElementById('powerToggle');
powerToggle.addEventListener('click',()=>{brightness.value=Number(brightness.value)?0:lastBrightness;scheduleThemeUpdate();});
document.addEventListener('DOMContentLoaded',()=>{
const v=window.WordclockStudioVisual,el=document.querySelector('.home-preview');
v.matrixPreview(el,-1,-1);
const cells=[...el.querySelectorAll('text')];
const mode=document.getElementById('homeDisplayMode'),note=document.getElementById('homePreviewNote');
const weatherStatus=document.getElementById('homeWeatherStatus');
const modes=['Thème choisi','Mode météo actif','Mode nuit','Programmation en cours','Aperçu temporaire','Mise à l’heure','Horloge éteinte'];
const notes=['Votre thème habituel est affiché.','Les couleurs suivent la météo.','Le mode nuit adapte la lumière.','Une programmation adapte votre horloge.','Un aperçu est affiché temporairement.','L’horloge attend de connaître l’heure.','La lumière de l’horloge est éteinte.'];
const weatherNotes=['La météo est désactivée.','La météo adapte les couleurs.','La météo est activée. En attente des données.','La météo est activée, mais son intensité est à 0 %.','La météo est activée, mais ne modifie pas l’affichage pour le moment.'];
const zones=['à l’arrière','à l’avant','sur les deux faces'];
let failures=0;
function paint(d){
if(!Number.isInteger(d.mode)||!modes[d.mode]||!Number.isInteger(d.weather)||!weatherNotes[d.weather]||!Number.isInteger(d.zone)||!zones[d.zone]||!(/^[0-9a-f]{846}$/.test(d.pixels)))throw Error('Affichage indisponible');
const colors=d.pixels.match(/.{6}/g).map(h=>v.rgb('#'+h));
const screen=c=>v.css(c.map(n=>255*Math.pow(n/255,0.42)));
for(let i=0;i<121;i++){
const lit=colors[i].some(Boolean),cell=cells[i];
cell.classList.toggle('lit',lit);
cell.style.fill=lit?screen(colors[i]):'';
cell.style.filter=lit?'drop-shadow(0 0 1px '+screen(colors[i])+')':'';
}
const sides=Array.from({length:4},(_,i)=>screen([0,1,2].map(k=>colors.slice(121+i*5,126+i*5).reduce((a,c)=>a+c[k],0)/5)));
el.classList.remove('front-off','rear-off');
el.style.boxShadow=`0 12px 24px 4px ${sides[0]}, -12px 0 24px 4px ${sides[1]}, 0 -12px 24px 4px ${sides[2]}, 12px 0 24px 4px ${sides[3]}`;
if(colors.slice(121).every(c=>!c.some(Boolean)))el.classList.add('rear-off');
const label=modes[d.mode];
mode.textContent=label;
mode.dataset.active=String(d.mode===1||d.mode===2||d.mode===3);
note.textContent=(d.mode===1?'Les couleurs suivent la météo '+zones[d.zone]+'.':notes[d.mode])+(d.capped?' Luminosité limitée par une programmation.':'');
weatherStatus.textContent=(d.weather===1?'La météo adapte les couleurs '+zones[d.zone]+'.':d.weather===4&&d.mode===2?'Activée, en pause pendant le mode nuit.':d.weather===4&&d.mode===3?'Activée, en pause pendant la programmation.':weatherNotes[d.weather])+(d.weather!==0&&Number.isInteger(d.temperature)?' · '+(d.temperature/10).toLocaleString('fr-CH',{minimumFractionDigits:1,maximumFractionDigits:1})+' °C':'');
document.getElementById('homeWeatherPanel').dataset.liveWeather=String(d.weather===1);
}
async function poll(){
let delay=1500;
try{
if(!document.hidden&&!document.getElementById('homeView').hidden&&!window.WordclockLocal.busy){
const d=await request('/api/display',{signal:AbortSignal.timeout(3000)});
if(!window.WordclockLocal.busy&&!document.getElementById('homeView').hidden){paint(d);failures=0;delay=d.animated?600:1500;}
}
}catch(e){
if(++failures>=2){mode.textContent='Aperçu indisponible';mode.dataset.active='false';note.textContent='Impossible de lire l’affichage actuel. Nouvelle tentative automatique.';weatherStatus.textContent='État de l’affichage momentanément indisponible.';document.getElementById('homeWeatherPanel').dataset.liveWeather='false';cells.forEach(c=>{c.classList.remove('lit');c.style.fill='';c.style.filter='';});el.classList.add('rear-off');}
delay=3000;
}finally{setTimeout(poll,delay);}
}
setTimeout(poll,1200);updateStatus();initialize();
});
function updateAmbienceLabels(){
ambEl('effectsDurationValue').textContent=(Number(ambEl('effectsDuration').value)/1000).toLocaleString('fr-CH')+' s';
ambEl('effectsIntensityValue').textContent=ambEl('effectsIntensity').value+' %';
ambEl('transitionValue').textContent=ambEl('transitionEnabled').checked?(Number(ambEl('transitionDuration').value)/1000).toLocaleString('fr-CH')+' s':'Instantané';
ambEl('effectsState').textContent=themeDraft?'Modifications non enregistrées.':ambEl('effectsEnabled').checked?'Les animations sont activées.':'Les animations sont désactivées.';
}
function markThemeDraft(){if(!initialized||applyingTheme)return;themeDraft=true;updateAnimationControls();updateHarmonyControls();updateAmbienceLabels();setControlsEnabled(true);ambEl('effectsMessage').textContent='Enregistrez pour appliquer vos modifications.';}
function editorValues(){
const front=animationControls.front.effect.value,spatial=front==='rainbow'?1:front==='chase'?2:0;
return{front:frontColor.value,rear:rearColor.value,harmony:harmony.value,frontEffect:spatial?'solid':front,frontSpeed:spatial?50:animationControls.front.speed.value,rearEffect:animationControls.rear.effect.value,rearSpeed:animationControls.rear.speed.value,
enabled:ambEl('effectsEnabled').checked?1:0,hourlyColor:ambEl('effectsHourly').checked?1:0,transition:ambEl('effectsTransition').value,chime:ambEl('effectsChime').value,spatial,spatialSpeed:spatial?animationControls.front.speed.value:50,duration:ambEl('effectsDuration').value,intensity:ambEl('effectsIntensity').value,fadeDuration:ambEl('transitionEnabled').checked?ambEl('transitionDuration').value:0};
}
async function ambienceAction(action){
if(!initialized||applyingTheme)return;
const selected=themes.find(t=>t.index===activePreset);if(!selected)return;
if(action==='reset'&&!confirm('Rétablir les couleurs et les animations d’origine de '+selected.name+' ?'))return;
if(action==='reset-all'&&!confirm('Effacer toutes les personnalisations de thèmes ? Vos autres réglages seront conservés.'))return;
const msg=ambEl(action==='reset-all'?'themeResetAllMessage':'effectsMessage');
const params={action,id:selected.id,...(action==='save'?editorValues():{})};
applyingTheme=true;revision++;clearTimeout(themeTimer);pending=false;setControlsEnabled(false);msg.textContent='Enregistrement…';
try{
if(currentRequest)await currentRequest;
await request('/api/theme',{method:'POST',body:new URLSearchParams({brightness:brightness.value,frontBrightness,rearBrightness})});
const data=await request('/api/themes/personalize',{method:'POST',headers:{'X-Wordclock-Action':'ambience'},body:new URLSearchParams(params)});
themeDraft=false;updateControls(data);await refreshThemeLibrary();
msg.textContent=action==='save'?'Thème enregistré.':action==='reset'?'Thème d’origine rétabli.':'Tous les thèmes d’origine sont rétablis.';
}catch(e){msg.textContent='Action non confirmée. Réessayez ou rechargez la page.';}
finally{applyingTheme=false;updateAmbienceLabels();setControlsEnabled(true);}
}
for(const c of Object.values(animationControls)){c.effect.addEventListener('change',markThemeDraft);c.speed.addEventListener('input',markThemeDraft);}
for(const key of['effectsEnabled','effectsHourly','effectsTransition','effectsChime','effectsDuration','effectsIntensity','transitionEnabled','transitionDuration'])ambEl(key).addEventListener('input',markThemeDraft);
ambEl('effectsSave').addEventListener('click',()=>ambienceAction('save'));
ambEl('effectsCancel').addEventListener('click',()=>{if(savedTheme&&!applyingTheme){themeDraft=false;updateControls(savedTheme);ambEl('effectsMessage').textContent='Modifications annulées.';setControlsEnabled(true);}});
ambEl('themeReset').addEventListener('click',()=>ambienceAction('reset'));
ambEl('themeResetAll').addEventListener('click',()=>ambienceAction('reset-all'));
ambEl('effectsTest').addEventListener('click',async()=>{if(themeDraft||applyingTheme)return;try{await request('/api/animations/test',{method:'POST',headers:{'X-Wordclock-Action':'animations'},body:new URLSearchParams({kind:ambEl('effectsTestKind').value})});ambEl('effectsMessage').textContent='Effet lancé sur l’horloge.';}catch(e){ambEl('effectsMessage').textContent='Test indisponible. Vérifiez que l’horloge est allumée et que les animations sont activées.';}});
async function refreshThemeLibrary(){
themes = await request("/api/themes?version=3&factoryOnly=1");
renderThemeLibrary();
}
const appearanceToggle=document.getElementById('appearanceToggle');
function setAppearance(dark){document.documentElement.dataset.appearance=dark?'dark':'light';appearanceToggle.textContent=dark?'Mode clair':'Mode sombre';appearanceToggle.setAttribute('aria-pressed',String(dark));}
let darkAppearance=false;try{darkAppearance=localStorage.getItem('wordclock-appearance')==='dark';}catch(e){}
setAppearance(darkAppearance);
appearanceToggle.addEventListener('click',()=>{darkAppearance=!darkAppearance;setAppearance(darkAppearance);try{localStorage.setItem('wordclock-appearance',darkAppearance?'dark':'light');}catch(e){}});
(()=>{
const fields=document.getElementById('faceFields'),picker=document.getElementById('facePicker'),msg=document.getElementById('faceMessage'),presets=document.getElementById('facePresets');
const sample=document.getElementById('faceSample');
const colors=[['Noir','#151515'],['Blanc','#F5F5F5'],['Anthracite','#454545'],['Gris','#909090'],['Rouge','#A13835'],['Bleu','#304D70'],['Vert','#536B49'],['Terracotta','#B46B50']];
let saved='#151515',busy=false;
function paint(el,c){const rgb=[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));const l=rgb[0]*.299+rgb[1]*.587+rgb[2]*.114;const v=rgb.map(n=>Math.round(n*.78+(l>135?0:255)*.22));el.style.setProperty('--face-color',c);el.style.setProperty('--face-unlit',`rgb(${v.join(',')})`);}
function draft(c){picker.value=c;paint(sample,c);for(const b of presets.children)b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===c.toLowerCase()));}
function apply(c){saved=c;paint(document.documentElement,c);draft(c);}
for(const[name,c]of colors){const b=document.createElement('button');b.type='button';b.dataset.color=c;const sw=document.createElement('span');sw.className='face-swatch';sw.style.background=c;b.append(sw,document.createTextNode(name));b.addEventListener('click',()=>{draft(c);saveFace();});presets.append(b);}
picker.addEventListener('input',()=>draft(picker.value));
async function load(){try{const data=await request('/api/appearance');if(!/^#[0-9a-f]{6}$/i.test(data.faceColor))throw Error('Invalid color');apply(data.faceColor);fields.disabled=false;msg.textContent='';}catch(e){msg.textContent='Apparence indisponible. Nouvelle tentative…';setTimeout(load,3000);}}
picker.addEventListener('change',saveFace);
async function saveFace(){if(busy)return;busy=true;fields.disabled=true;try{const data=await request('/api/appearance',{method:'POST',body:new URLSearchParams({faceColor:picker.value})});apply(data.faceColor);void confirmStored(msg,'Couleur appliquée');}catch(e){draft(saved);msg.textContent='Échec de la modification';}finally{busy=false;fields.disabled=false;}}
function init(){
try{window.WordclockStudioVisual.matrixPreview(sample);}
catch(error){console.error('Face preview initialization failed',error);}
load();
}
document.addEventListener('DOMContentLoaded',init,{once:true});
})();
(()=>{
document.addEventListener("DOMContentLoaded",()=>{
const el = id => document.getElementById(id);
const change = el("wifiChange"),forget = el("wifiForget"),message = el("wifiMessage");
let busy = false;
function enable(value){change.disabled = forget.disabled = !value;}
async function refresh(){
if(busy)return;
try{
const data = await request("/api/wifi");
el("wifiSsid").textContent = data.ssid || "—";
el("wifiIp").textContent = data.ip;
el("wifiHost").textContent = data.connected ? data.hostname:"—";
el("wifiState").textContent = data.connected ? "Connectée":data.offlineAP ? "Accès direct (sans routeur)":"Déconnectée";
enable(data.connected || data.offlineAP);
}catch(_){el("wifiState").textContent = "Indisponible";enable(false);}
}
async function act(action){
if(busy || !confirm(action === "forget" ? "Effacer les identifiants Wi-Fi et redémarrer ? Les thèmes sont conservés.":"Ouvrir le portail Wi-Fi ? Cette interface sera temporairement inaccessible."))return;
busy = true;enable(false);
message.textContent = "Authentification administrateur requise…";
try{
await request("/api/wifi",{method:"POST",headers:{"X-Wordclock-Action":"wifi"},body:new URLSearchParams({action})});
message.textContent = "Commande acceptée. Connecte-toi à Wordclock-Setup (mot de passe : Wordclock123), puis ouvre http://192.168.4.1. Après configuration, recharge cette page.";
}catch(err){
message.textContent = "Commande non confirmée : " + err.message + ". Vérifie si le portail est apparu avant de réessayer.";
busy = false;refresh();
}
}
change.addEventListener("click",()=> act("change"));
forget.addEventListener("click",()=> act("forget"));
el("settingsTab").addEventListener("click",refresh);
refresh();
});
})();
document.addEventListener('DOMContentLoaded',()=>{
const el = id => document.getElementById(id);
const host = el('accessHost'),ip = el('accessIp'),message = el('accessMessage');
if(!host || !ip || !message)return;
async function copy(field){
if(!field.value)return;
try{
if(navigator.clipboard && window.isSecureContext)await navigator.clipboard.writeText(field.value);
else{field.focus();field.select();field.setSelectionRange(0,field.value.length);if(!document.execCommand('copy'))throw new Error('copy');}
message.textContent = 'Adresse copiée.';
}catch(_){field.focus();field.select();message.textContent = 'Adresse sélectionnée : copiez-la manuellement.';}
}
el('copyHost').addEventListener('click',()=> copy(host));
el('copyIp').addEventListener('click',()=> copy(ip));
async function refreshAccess(){
try{
const data = await request('/api/wifi');
ip.value =(data.connected || data.offlineAP)&& /^\d{1,3}(\.\d{1,3}){3}$/.test(data.ip)? 'http://' + data.ip + '/':'';
}catch(_){ip.value = '';}
el('copyIp').disabled = !ip.value;
}
const platform = el('accessPlatform');
const help ={android:'Dans Chrome, ouvrez le menu ⋮ puis Ajouter à l’écran d’accueil (ou Créer un raccourci), et confirmez.',ios:'Dans Safari, ouvrez Partager, puis Sur l’écran d’accueil et confirmez.',windows:'Dans Chrome, recherchez Créer un raccourci dans le menu. Sinon, sur le bureau Windows, clic droit > Nouveau > Raccourci et saisissez http://wordclock.local/.'};
platform.value = /Android/i.test(navigator.userAgent)? 'android':/iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)? 'ios':'windows';
function updateHelp(){el('accessHelp').textContent = help[platform.value];}
platform.addEventListener('change',updateHelp);updateHelp();
el('settingsTab').addEventListener('click',refreshAccess);
refreshAccess();
});
document.addEventListener('DOMContentLoaded',()=>{
const el = id => document.getElementById(id);
const phone = el('clockPhone'),manual = el('clockManual'),apply = el('clockApply');
const source = el('clockSource'),message = el('clockMessage');
let busy = false;
function show(data,fill){
source.textContent = !data.valid ? 'Heure non réglée':'Source : ' +({ntp:'Internet (NTP)',manual:'Réglage local',unknown:'Non déterminée'}[data.source]|| 'Non déterminée');
if(fill && document.activeElement !== manual)manual.value = data.local || '';
}
function lock(value){phone.disabled = manual.disabled = apply.disabled = value;}
async function refresh(){
if(busy)return;
try{show(await request('/api/clock'),true);lock(false);}
catch(_){source.textContent = 'Réglage de l’heure indisponible';lock(true);}
}
async function save(fields){
if(busy)return;
busy = true;lock(true);
try{
show(await request('/api/clock',{method:'POST',headers:{'X-Wordclock-Action':'clock'},body:new URLSearchParams(fields)}),true);
message.textContent = 'Heure synchronisée.';
}catch(e){message.textContent = 'Réglage non confirmé : '+e.message;}
finally{busy = false;lock(false);}
}
phone.addEventListener('click',()=> save({epoch:String(Math.floor(Date.now()/1000))}));
apply.addEventListener('click',()=>{
const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(manual.value);
if(!m || !manual.checkValidity()){message.textContent = 'Date ou heure invalide.';return;}
const[_,year,month,day,hour,minute,second='00']= m;
save({year,month,day,hour,minute,second});
});
el('settingsTab').addEventListener('click',refresh);
refresh();
});
(()=>{
const el=id=>document.getElementById(id),fields=el('rulesFields'),msg=el('rulesMessage');
const effects=transitionNames.slice(1);
const keys=['start','end','days','month','day','action','value'];
let rules=null,selected=null,dirty=false,busy=false;
const list=el('rulesList'),add=el('rulesAdd');
const option=(text,value)=>{const o=document.createElement('option');o.textContent=text;o.value=value;return o;};
['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'].forEach((name,i)=>{const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.id='ruleDay'+i;label.append(input,document.createTextNode(name));el('ruleDays').append(label);});
function valid(r){if(!r||!keys.every(k=>Number.isInteger(r[k])))return false;const{start,end,days,month,day,action,value}=r;return start>=0&&start<1440&&end>=0&&end<1440&&days>=1&&days<=127&&month>=0&&month<=12&&day>=0&&day<=31&&(!month||!day||day<=[0,31,29,31,30,31,30,31,31,30,31,30,31][month])&&value>=0&&value<=255&&(action===0||(action===1&&value<themes.length&&start!==end)||(action===2&&value<=100&&start!==end)||(action===3&&value>=1&&value<=effects.length&&start===end));}
function validate(list){if(!Array.isArray(list)||list.length!==16||!list.every(valid))throw Error('Configuration invalide');return list.map(r=>Object.fromEntries(keys.map(k=>[k,r[k]])));}
function decode(hex){if(typeof hex!=='string'||!/^([0-9a-f]{18}){16}$/i.test(hex))throw Error('Réponse invalide');const bytes=hex.match(/../g).map(x=>parseInt(x,16));return validate(Array.from({length:16},(_,i)=>{const b=bytes.slice(i*9,i*9+9);return{start:b[0]+256*b[1],end:b[2]+256*b[3],days:b[4],month:b[5],day:b[6],action:b[7],value:b[8]};}));}
function encode(list){return validate(list).flatMap(r=>[r.start&255,r.start>>8,r.end&255,r.end>>8,r.days,r.month,r.day,r.action,r.value]).map(b=>b.toString(16).padStart(2,'0')).join('');}
function time(n){return String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');}
function minute(id){const v=el(id).value;if(!/^\d{2}:\d{2}$/.test(v))throw Error('Heure invalide');const[h,m]=v.split(':').map(Number);return h*60+m;}
function actions(value){const action=Number(el('ruleAction').value);el('ruleEndRow').hidden=action===3;el('ruleValueRow').hidden=action===2;el('ruleCapRow').hidden=action!==2;el('ruleValue').replaceChildren(...(action===3?effects:themes.map(t=>t.name)).map((x,i)=>option(x,i+(action===3?1:0))));if(value!==undefined)el('ruleValue').value=value;}
const empty=()=>({start:1080,end:1320,days:127,month:0,day:0,action:0,value:0});
function daysText(days){return({127:'Tous les jours',62:'En semaine',65:'Le week-end'})[days]||['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'].filter((_,i)=>days&(1<<i)).join(', ');}
function showList(){list.replaceChildren();if(!rules)return;let count=0;rules.forEach((r,i)=>{if(!r.action)return;count++;const card=document.createElement('article');card.className='rule-card';const title=document.createElement('strong');title.textContent=r.action===1?themes[r.value]?.name:r.action===2?'Luminosité maximale : '+r.value+' %':effects[r.value-1];const detail=document.createElement('p');detail.className='muted';detail.textContent=(r.action===3?time(r.start):time(r.start)+' – '+time(r.end))+' · '+daysText(r.days)+(r.month?' · Mois '+r.month:'')+(r.day?' · Jour '+r.day:'');const buttons=document.createElement('div');buttons.className='rule-buttons';for(const[name,fn]of[['Modifier',()=>edit(i)],['Supprimer',()=>{if(confirm('Supprimer cette programmation ?'))run(()=>persist(rules.map((x,j)=>j===i?empty():x)));}]]){const b=document.createElement('button');b.type='button';b.className='action-button';b.textContent=name;b.disabled=busy||selected!==null;b.addEventListener('click',fn);buttons.append(b);}card.append(title,detail,buttons);list.append(card);});if(!count){const p=document.createElement('p');p.className='muted';p.textContent='Aucune programmation. Ajoutez par exemple une ambiance du soir.';list.append(p);}add.disabled=busy||selected!==null||rules.every(r=>r.action);}
function edit(i){if(busy||selected!==null)return;selected=i;const r=rules[i].action?rules[i]:{...empty(),action:1};el('ruleLegend').textContent=rules[i].action?'Modifier la programmation':'Nouvelle programmation';el('ruleAction').value=r.action;el('ruleStart').value=time(r.start);el('ruleEnd').value=time(r.end);el('ruleMonth').value=r.month;el('ruleDay').value=r.day;el('ruleCap').value=r.action===2?r.value:50;for(let j=0;j<7;j++)el('ruleDay'+j).checked=!!(r.days&(1<<j));el('rulePreset').value=[127,62,65].includes(r.days)?String(r.days):'custom';el('ruleDays').hidden=el('rulePreset').value!=='custom';el('ruleDateMode').value=r.month||r.day?'custom':'any';el('ruleDateFields').hidden=el('ruleDateMode').value==='any';actions(r.value);fields.hidden=false;fields.disabled=false;dirty=true;showList();msg.textContent='Brouillon — non enregistré.';}
function close(){selected=null;dirty=false;fields.hidden=true;showList();}
function capture(){const action=Number(el('ruleAction').value),start=minute('ruleStart');let days=0;for(let i=0;i<7;i++)if(el('ruleDay'+i).checked)days|=1<<i;const any=el('ruleDateMode').value==='any';const r={start,end:action===3?start:minute('ruleEnd'),days,month:any?0:Number(el('ruleMonth').value),day:any?0:Number(el('ruleDay').value),action,value:action===2?Number(el('ruleCap').value):Number(el('ruleValue').value)};if(!valid(r))throw Error('Vérifiez les jours, les dates et les heures (début et fin différents).');return r;}
async function run(work){if(busy)return;busy=true;fields.disabled=true;showList();try{await work();}catch(e){msg.textContent=e.message;}finally{busy=false;fields.disabled=!rules||selected===null;showList();}}
async function persist(next){const wire=encode(next);msg.textContent='Enregistrement en cours…';const r=await request('/api/automations',{method:'POST',headers:{'X-Wordclock-Action':'automations'},body:new URLSearchParams({rules:wire})});const saved=decode(r.rules);if(encode(saved)!==wire)throw Error('Enregistrement non confirmé.');rules=saved;close();msg.textContent='Programmations enregistrées.';}
document.addEventListener('wordclock:settings-section',e=>{if(e.detail==='rules'&&!dirty)run(async()=>{if(!themes.length)await refreshThemeLibrary();const r=await request('/api/automations');if(r.version!==1)throw Error('Version incompatible');rules=decode(r.rules);close();msg.textContent='';});});
add.addEventListener('click',()=>{if(rules)edit(rules.findIndex(r=>!r.action));});
el('ruleAction').addEventListener('change',()=>{actions();if(Number(el('ruleAction').value)!==3&&el('ruleStart').value&&el('ruleStart').value===el('ruleEnd').value)el('ruleEnd').value=time((minute('ruleStart')+60)%1440);});
el('rulePreset').addEventListener('change',()=>{const v=el('rulePreset').value;el('ruleDays').hidden=v!=='custom';if(v!=='custom')for(let i=0;i<7;i++)el('ruleDay'+i).checked=!!(Number(v)&(1<<i));});
el('ruleDateMode').addEventListener('change',()=>{el('ruleDateFields').hidden=el('ruleDateMode').value==='any';});
el('rulesSave').addEventListener('click',()=>run(async()=>{const r=capture();await persist(rules.map((x,i)=>i===selected?r:x));}));
el('rulesCancel').addEventListener('click',()=>{if(!busy){close();msg.textContent='Modifications annulées.';}});
})();
document.addEventListener('DOMContentLoaded',()=>{
const el=id=>document.getElementById(id),buttons=[...document.querySelectorAll('[data-settings]')];
let section='general';
function open(key){section=key;for(const b of buttons){const active=b.dataset.settings===key;b.setAttribute('aria-pressed',String(active));el('settings-'+b.dataset.settings).hidden=!active;}document.dispatchEvent(new CustomEvent('wordclock:settings-section',{detail:key}));}
buttons.forEach(b=>b.addEventListener('click',()=>open(b.dataset.settings)));
el('settingsTab').addEventListener('click',()=>open(section));
const v=window.WordclockStudioVisual,preview=el('effectPreview'),setTime=v.matrixPreview(preview,8,25),cells=[...preview.querySelectorAll('text')];
let start=performance.now(),last=0,lastFrame='';
const reset=()=>{start=performance.now();lastFrame='';};
el('themeEditor').addEventListener('toggle',reset);
el('effectReplay').addEventListener('click',reset);
el('effectsFields').addEventListener('input',reset);
function draw(now){
if(!document.hidden&&!el('libraryView').hidden&&el('themeEditor').open&&now-last>33){
last=now;const select=el('effectsTransition'),kind=Number(select.value),duration=Number(el('effectsDuration').value)||2500,strength=Number(el('effectsIntensity').value)/100;
const t=Math.min(1,Math.max(0,(now-start)/duration)),p=t*255,wave=(d,w)=>Math.max(0,1-d/w),ease=x=>x*x*(3-2*x);
const frame=[kind,Math.round(p),strength,frontColor.value].join(':');if(frame===lastFrame){requestAnimationFrame(draw);return;}lastFrame=frame;
setTime(8,25);preview.style.setProperty('--front',frontColor.value);
el('effectPreviewName').textContent=select.selectedOptions[0]?.textContent+' — simulation locale, sans action sur l’horloge';
const envelope=ease(Math.min(1,t*8,(1-t)*8));
cells.forEach((c,i)=>{const x=i%11,y=Math.floor(i/11),r=Math.abs(x-5)+Math.abs(y-5),hash=(i*73+19)%117;let a=0,reveal=1;
if(i<117&&t<1){switch(kind){case 1:reveal=ease(t);break;case 2:a=wave(Math.abs(x*24-p),48);break;case 3:{const h=(Math.floor(p*13/256)+x*7)%14;a=h>=y&&h-y<3?(3-h+y)/3:0;break;}case 4:reveal=ease(Math.max(0,Math.min(1,(t*141-i)/24)));break;case 5:a=wave(Math.abs(r*24-p),48);break;case 7:reveal=ease(Math.max(0,Math.min(1,(t*141-hash)/24)));break;case 8:a=wave(Math.abs((x+y)*12-p),42);break;case 9:a=wave(Math.abs(x*24-(p<128?p*2:(255-p)*2)),34);break;case 10:a=wave(Math.abs(hash*17%256-p),18);break;case 11:a=wave(Math.abs(((x-5)**2+(y-5)**2)*5-p),48);break;}}
const lit=c.classList.contains('lit');c.style.fill=lit?frontColor.value:a>0?frontColor.value:'';c.style.opacity=lit?String(1-(1-reveal)*strength*.75):a>0?String(a*envelope*strength):'';
});
}
requestAnimationFrame(draw);
}
requestAnimationFrame(draw);
});
(()=>{const el=id=>document.getElementById(id),fields=el('weatherFields'),msg=el('weatherMessage');let saved=null,dirty=false,busy=false;const homeToggle=el('homeWeatherToggle'),homeStatus=el('homeWeatherStatus');let homeError='';const keys=['Lat','Lon','Enabled','Forecast','Zone','Intensity'];let places=[],chosen=null,searchId=0;const city=el('weatherCity'),results=el('weatherResults'),searchStatus=el('weatherSearchStatus');const labelPlace=p=>[p.name,p.admin1,p.country].filter(Boolean).join(' — ');async function searchCity(){const q=city.value.trim(),id=++searchId;results.hidden=true;places=[];if(q.length<2){searchStatus.textContent='Saisissez au moins deux caractères.';return;}searchStatus.textContent='Recherche…';try{const u=new URL('https://geocoding-api.open-meteo.com/v1/search');u.search=new URLSearchParams({name:q,count:10,language:'fr',format:'json'});const r=await fetch(u,{signal:AbortSignal.timeout(10000),credentials:'omit',referrerPolicy:'no-referrer'});if(!r.ok)throw Error('HTTP '+r.status);const d=await r.json();if(id!==searchId)return;places=(d.results||[]).filter(p=>typeof p.name==='string'&&Number.isFinite(p.latitude)&&Number.isFinite(p.longitude)&&Math.abs(p.latitude)<=90&&Math.abs(p.longitude)<=180);results.replaceChildren(new Option('Choisir une localité…',''));places.forEach((p,i)=>results.add(new Option(labelPlace(p),String(i))));results.hidden=!places.length;searchStatus.textContent=places.length?'Sélectionnez votre localité.':'Aucun résultat. Essayez une ville proche.';}catch(e){if(id===searchId)searchStatus.textContent='Recherche indisponible. Vous pouvez saisir les coordonnées manuellement.';}}el('weatherSearch').addEventListener('click',searchCity);city.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchCity();}});city.addEventListener('input',()=>{++searchId;results.hidden=true;searchStatus.textContent='';});results.addEventListener('change',()=>{if(results.value==='')return;const p=places[Number(results.value)];if(!p)return;el('weatherLat').value=p.latitude.toFixed(5);el('weatherLon').value=p.longitude.toFixed(5);chosen={name:labelPlace(p),lat:Math.round(p.latitude*100000),lon:Math.round(p.longitude*100000)};city.value=chosen.name;results.hidden=true;searchStatus.textContent='Coordonnées remplies. Enregistrez pour appliquer.';dirty=true;msg.textContent='Modifications non enregistrées.';});const front=['#ffe8ae','#e2e8f0','#a5dcff','#ded1ff','#ffffff','#dddeda','#d5dfff'],rear=['#ed9b29','#64748b','#2266df','#7036ba','#8dddf7','#909b9e','#293d86'];document.addEventListener('DOMContentLoaded',()=>{window.WordclockStudioVisual.matrixPreview(el('weatherPreview'),8,25);preview();},{once:true});function preview(){const p=Number(el('weatherDemo').value),v=el('weatherPreview'),z=Number(el('weatherZone').value),a=Number(el('weatherIntensity').value);const visual=window.WordclockStudioVisual;const f=savedTheme?.front||frontColor.value||'#ffe8ae',r=(savedTheme?.effectiveRear||effectiveRear)||'#64748b';const blend=(base,hex,amount)=>visual.css(visual.rgb(base).map((n,i)=>n+(visual.rgb(hex)[i]-n)*amount/100));v.style.setProperty('--front',blend(f,front[p],z===0?0:a));v.style.setProperty('--weather-rear',blend(r,rear[p],z===1?0:a));v.dataset.motion=String(z!==1&&a>0&&p>=2&&p<=5);el('weatherLevel').textContent=a+' %';}function homeState(d){
homeToggle.setAttribute('aria-pressed',String(!!d.enabled));
homeToggle.textContent=d.enabled?'Activé':'Désactivé';
if(homeError)homeStatus.textContent=homeError;
}function status(d){homeState(d);const labels={disabled:'Mode désactivé',waiting:'En attente de données',ok:'Données reçues',memory:'Mémoire insuffisante',network:'Connexion indisponible',response:'Réponse invalide',connect:'Connexion impossible',send:'Envoi incomplet',header:'En-tête incomplet','header-limit':'En-tête trop long','http-code':'Code HTTP inattendu','body-limit':'Réponse trop volumineuse',encoding:'Encodage inattendu','body-timeout':'Réception interrompue','body-empty':'Réponse vide',json:'JSON invalide','json-empty':'Réponse JSON vide','json-incomplete':'Réponse JSON incomplète','json-memory':'Mémoire de décodage insuffisante','json-depth':'JSON trop imbriqué',fields:'Champs manquants',timestamp:'Date météo incohérente',forecast:'Prévision indisponible',range:'Valeurs invalides',expired:'Données expirées'};el('weatherStatus').textContent=(d.valid&&d.status!=='ok'?'Dernières données valides conservées — '+(labels[d.status]||'État inconnu'):(labels[d.status]||'État inconnu'))+(d.valid?' · '+(d.code>=95?'Orage':[71,73,75,77,85,86].includes(d.code)?'Neige':[45,48].includes(d.code)?'Brouillard':d.code>=51?'Pluie':d.code>=2?'Nuageux':d.day?'Dégagé':'Nuit dégagée')+' · '+(d.temperature/10).toFixed(1)+' °C (actuel) · il y a '+Math.floor(d.age/60)+' min':' · thème habituel');}function show(d){saved=d;status(d);++searchId;results.hidden=true;searchStatus.textContent='';chosen=null;city.value='';try{const p=JSON.parse(localStorage.getItem('wordclock.weather.place')||'null');if(p&&p.lat===d.lat&&p.lon===d.lon&&typeof p.name==='string'){chosen=p;city.value=p.name;}}catch(e){}el('weatherLat').value=d.lat/100000;el('weatherLon').value=d.lon/100000;el('weatherEnabled').checked=!!d.enabled;for(const k of['Forecast','Zone','Intensity'])el('weather'+k).value=d[k.toLowerCase()];dirty=false;preview();}async function run(fn){if(busy)return;busy=true;fields.disabled=true;homeToggle.disabled=true;try{await fn();}catch(e){msg.textContent='Action non confirmée : '+e.message;}finally{busy=false;fields.disabled=!saved;homeToggle.disabled=!saved;}}const post=body=>request('/api/weather',{method:'POST',headers:{'X-Wordclock-Action':'weather'},body:new URLSearchParams(body)});function load(){run(async()=>{show(await request('/api/weather'));msg.textContent='';});}document.addEventListener('wordclock:settings-section',e=>{if(e.detail==='weather'&&!dirty)load();});for(const k of keys)el('weather'+k).addEventListener('input',()=>{dirty=true;preview();msg.textContent='Modifications non enregistrées.';});el('weatherDemo').addEventListener('change',preview);el('weatherCancel').addEventListener('click',()=>{if(saved)show(saved);msg.textContent='Modifications annulées.';});el('weatherSave').addEventListener('click',()=>run(async()=>{const lat=el('weatherLat'),lon=el('weatherLon');if(!lat.value||!lon.value||!lat.checkValidity()||!lon.checkValidity())throw Error('Coordonnées invalides');const data={lat:Math.round(Number(lat.value)*100000),lon:Math.round(Number(lon.value)*100000),enabled:el('weatherEnabled').checked?1:0,forecast:Number(el('weatherForecast').value),zone:Number(el('weatherZone').value),intensity:Number(el('weatherIntensity').value)};const d=await post(data);if(!Object.keys(data).every(k=>d[k]===data[k]))throw Error('Sauvegarde non confirmée');try{if(chosen&&chosen.lat===data.lat&&chosen.lon===data.lon)localStorage.setItem('wordclock.weather.place',JSON.stringify(chosen));else localStorage.removeItem('wordclock.weather.place');}catch(e){}show(d);msg.textContent='Réglages enregistrés.';}));el('weatherRefresh').addEventListener('click',()=>run(async()=>{if(dirty)throw Error('Enregistrez ou annulez les modifications');if(!saved.enabled)throw Error('Activez le mode météo');status(await post({refresh:1}));msg.textContent='Actualisation demandée. Le résultat sera affiché automatiquement.';}));function pollHome(){if(busy||document.hidden||window.WordclockLocal.busy||el('homeView').hidden)return;run(async()=>{try{const d=await request('/api/weather');homeError='';if(!dirty)show(d);else{saved=d;status(d);}}catch(e){homeError='Impossible de vérifier la météo. Réessayez dans un instant.';homeStatus.textContent=homeError;throw e;}});}
homeToggle.addEventListener('click',()=>run(async()=>{try{
homeError='';const before=await request('/api/weather');
const data={lat:before.lat,lon:before.lon,enabled:before.enabled?0:1,forecast:before.forecast,zone:before.zone,intensity:before.intensity};
const d=await post(data);if(!Object.keys(data).every(k=>d[k]===data[k]))throw Error('Modification non confirmée');
if(dirty){saved=d;el('weatherEnabled').checked=!!d.enabled;status(d);}else show(d);
}catch(e){homeError='Impossible de confirmer le changement. Réessayez.';homeStatus.textContent=homeError;throw e;}}));
el('homeWeatherSettings').addEventListener('click',()=>{el('settingsTab').click();document.querySelector('[data-settings="weather"]').click();});
el('homeTab').addEventListener('click',()=>setTimeout(pollHome,0));
setTimeout(pollHome,1500);
setInterval(()=>{if(!busy&&!document.hidden&&!window.WordclockLocal.busy&&!el('settingsView').hidden&&!el('settings-weather').hidden)run(async()=>{const d=await request('/api/weather');homeError='';status(d);if(!dirty)saved=d;});else pollHome();},15000);})();
;
(()=>{
'use strict';
const el = id => document.getElementById(id);
const fields = el('nightFields'),enabled = el('nightEnabled'),start = el('nightStart'),end = el('nightEnd'),mode = el('nightMode'),brightness = el('nightBrightness');
const defaults ={enabled:false,startMinute:1350,endMinute:420,brightness:13,mode:0};
let ready = false,busy = false,dirty = false,timer;
const toTime = n => `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
const toMinute = s =>{const[h,m]= s.split(':').map(Number);return h*60+m;};
function message(text,error=false){el('nightMessage').textContent=text;el('nightMessage').classList.toggle('error',error);}
function preview(){
el('nightBrightnessValue').textContent = `${(Number(brightness.value)*100/255).toFixed(1).replace('.',',')} %`;
el('nightBrightnessRow').hidden = mode.value === '2';
el('nightHint').textContent = start.value === end.value ? 'Horaires identiques : le mode nuit ne s’activera pas.':'La luminosité nocturne est un plafond. Les horaires utilisent l’heure locale de l’horloge.';
}
function fill(n){enabled.checked=n.enabled;start.value=toTime(n.startMinute);end.value=toTime(n.endMinute);mode.value=String(n.mode);brightness.value=String(n.brightness);preview();}
function status(n){document.dispatchEvent(new CustomEvent("wordclock:night-status",{detail:n}));const e=el('nightStatus');e.textContent=n.active?'Actif':n.enabled?'Programmé':'Désactivé';e.classList.toggle('active',n.active);}
async function request(options={}){return window.WordclockLocal.run(async()=>{const r=await fetch('/api/night',{cache:'no-store',...options});if(!r.ok)throw Error(`HTTP ${r.status}`);return await r.json();});}
async function poll(){
if(!busy && !window.WordclockLocal.busy && !document.hidden){
busy=true;
try{const n=await request();status(n);if(!dirty)fill(n);if(!ready){ready=true;fields.disabled=false;message('');}}
catch(e){el('nightStatus').textContent='Indisponible';el('nightStatus').classList.remove('active');if(!ready)message('Mode nuit inaccessible : '+e.message,true);}
finally{busy=false;}
}
setTimeout(poll,30000);
}
function schedule(){dirty=true;preview();clearTimeout(timer);message('Enregistrement en attente…');timer=setTimeout(save,500);}
el('nightForm').addEventListener('input',schedule);
el('nightForm').addEventListener('change',schedule);
el('nightReset').addEventListener('click',()=>{fill(defaults);schedule();});
el('nightForm').addEventListener('submit',e=>{e.preventDefault();schedule();});
async function save(){
if(!ready || !dirty || fields.disabled)return;
if(!el('nightForm').checkValidity()){message('Veuillez renseigner des horaires valides.',true);return;}
while(busy){await new Promise(resolve=>setTimeout(resolve,50));}
if(fields.disabled || !dirty)return;
clearTimeout(timer);
const body=new URLSearchParams({enabled:enabled.checked?'1':'0',startMinute:String(toMinute(start.value)),endMinute:String(toMinute(end.value)),brightness:brightness.value,mode:mode.value});
busy=true;fields.disabled=true;message("Envoi en cours…");
try{const n=await request({method:'POST',body});fill(n);status(n);dirty=false;void confirmStored(el('nightMessage'),'Paramètres appliqués');}
catch(e){dirty=true;message('Échec de l’enregistrement : '+e.message,true);}
finally{busy=false;fields.disabled=false;}
}
poll();
})();
;
;
(()=>{
'use strict';
const byId=id=>document.getElementById(id);
const matrix =['ILAESTBDEUX','QUATREDCINQ','SIXNEUFONZE','UNEHSEPTDIX','HUITFTROISZ','UMIDIHEURES','MINUITSETFA','MOINSOVINGT','DIXTLESDEMI','QUARTUCINQO','WGBSDLO****'];
function timePixels(hour,minute){
const lit=new Set();
if(!Number.isInteger(hour)||hour<0||hour>23||!Number.isInteger(minute)||minute<0||minute>59)return lit;
const add=(start,length)=>{for(let i=0;i<length;i++)lit.add(start+i);};
const step=Math.floor(minute/5);
if(step>=7)hour=(hour+1)%24;
add(0,2);add(3,3);
const hours=[[66,6],[33,3],[7,4],[49,5],[11,6],[18,4],[22,3],[37,4],[44,4],[25,4],[41,3],[29,4]];
if(hour===12)add(56,4);else{add(...hours[hour%12]);if(hour!==0)add(60,hour%12===1?5:6);}
const mins=[[],[[105,4]],[[88,3]],[[73,2],[99,5]],[[83,5]],[[83,5],[105,4]],[[73,2],[95,4]],[[77,5],[83,5],[105,4]],[[77,5],[83,5]],[[77,5],[92,2],[99,5]],[[77,5],[88,3]],[[77,5],[105,4]]];
mins[step].forEach(w=>add(...w));add(117,minute%5);return lit;
}
function matrixPreview(element,hour=8,minute=0){
const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 110 110');svg.setAttribute('aria-hidden','true');
const cells=Array.from(matrix.join(''),(letter,i)=>{const t=document.createElementNS(svg.namespaceURI,'text');t.setAttribute('x',String(5+i%11*10));t.setAttribute('y',String(8+Math.floor(i/11)*10));t.textContent=letter==='*'?'·':letter;svg.append(t);return t;});
element.replaceChildren(svg);element.classList.add('matrix-preview');
function setTime(h,m){const lit=timePixels(h,m);cells.forEach((c,i)=>c.classList.toggle('lit',lit.has(i)));}
setTime(hour,minute);return setTime;
}
const rgb = hex =>[1,3,5].map(i => parseInt(hex.slice(i,i+2),16));
const css = c => '#' + c.map(x => Math.max(0,Math.min(255,Math.round(x))).toString(16).padStart(2,'0')).join('');
function hsv(c){
const[r,g,b]= c.map(x=>x/255),v=Math.max(r,g,b),d=v-Math.min(r,g,b);
let h=0;
if(d)h=60*(v===r?(g-b)/d:v===g?(b-r)/d+2:(r-g)/d+4);
return[(h+360)%360,v?d/v:0,v];
}
function fromHsv(h,s,v){
h=((h%360)+360)%360;
const c=v*s,x=c*(1-Math.abs(h/60%2-1)),m=v-c;
return[[c,x,0],[x,c,0],[0,c,x],[0,x,c],[x,0,c],[c,0,x]][Math.floor(h/60)].map(n=>Math.round((n+m)*255));
}
function rotate(c,degrees){const[h,s,v]=hsv(c);return fromHsv(h+degrees,s,v);}
const period=c=>30000-290*Number(c.speed.value);
function effect(base,c,now,i=0){
const t=((now-c.start)%period(c))/period(c);
const phase=Math.floor(t*256)/256;
let level=255;
switch(c.effect.value){
case 'solid':return base;
case 'breathing':level=40+215*(1+Math.cos(phase*2*Math.PI))/2;break;
case 'color-cycle':return rotate(base,t*360);
case 'rainbow':return fromHsv((Math.floor(i*256/20)/256-phase)*360,1,Math.max(...base)/255);
case 'chase':level=12+243*Math.pow((1+Math.cos((Math.floor(i*256/20)/256-phase)*2*Math.PI))/2,4);break;
}
return base.map(n=>n?Math.min(255,Math.floor(n*Math.floor(level)/256)+1):0);
}
function sampleSpec(base,kind,speed,index,count){
const value=Number(speed??50);
const normalPeriod=30-.29*Math.max(0,Math.min(100,Number.isFinite(value)?value:50));
const period=Math.max(.65,Math.min(8,normalPeriod/1.8));
const palette=Array.from({length:6},(_,i)=>kind==='rainbow'?fromHsv(-i*60,1,Math.max(...base)/255):rotate(base,i*60));
return{period,delay:(kind==='rainbow'||kind==='chase')?-period*((count-index)%count)/count:0,palette:palette.map(css)};
}
function animateSample(element,base,kind,speed,pixels,count){
element.style.setProperty('--front',css(base));
element.style.setProperty('--sample-base',css(base));
const spec=sampleSpec(base,kind,speed,0,count);
spec.palette.forEach((color,i)=>element.style.setProperty('--sample-c'+i,color));
element.style.setProperty('--sample-period',spec.period+'s');
for(const{node,i}of pixels){
node.dataset.sampleEffect=kind;
node.style.setProperty('--sample-delay',((kind==='rainbow'||kind==='chase')?-spec.period*((count-i)%count)/count:0)+'s');
}
}
function rearSample(element){
const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 110 110');svg.setAttribute('aria-hidden','true');
const pixels=Array.from({length:20},(_,i)=>{
const side=Math.floor(i/5),t=i%5*18+19;
const xy=[[t,10],[100,t],[110-t,100],[10,110-t]][side];
const node=document.createElementNS(svg.namespaceURI,'circle');
node.setAttribute('cx',xy[0]);node.setAttribute('cy',xy[1]);node.setAttribute('r','13');svg.append(node);return{node,i};
});
element.replaceChildren(svg);return pixels;
}
window.WordclockStudioVisual=Object.freeze({timePixels,matrixPreview,rgb,css,rotate,effect,sampleSpec,animateSample,rearSample});
})();
;
(()=>{
'use strict';
const el=id=>document.getElementById(id);
for(const[id,view]of[['homeTab','homeView'],['themesTab','libraryView'],['settingsTab','settingsView']]){
el(id).addEventListener('click',()=>{
for(const v of['homeView','libraryView','settingsView'])el(v).hidden=v!==view;
for(const tab of['homeTab','themesTab','settingsTab'])el(tab).setAttribute('aria-pressed',String(tab===id));
});
}
})();
;
(()=>{
'use strict';
const el = id => document.getElementById(id);
const zones =[['Europe/Zurich','Suisse — Zurich'],['Europe/Paris','France — Paris'],['Europe/Berlin','Allemagne — Berlin'],['Europe/London','Royaume-Uni — Londres'],['Europe/Lisbon','Portugal — Lisbonne'],['Europe/Athens','Grèce — Athènes'],['Etc/UTC','UTC'],['America/New_York','États-Unis — New York'],['America/Toronto','Canada — Toronto'],['America/Los_Angeles','États-Unis — Los Angeles'],['Asia/Tokyo','Japon — Tokyo']];
const colors =[['Noir','#151515'],['Blanc','#F5F5F5'],['Anthracite','#454545'],['Gris','#909090'],['Rouge','#A13835'],['Bleu','#304D70'],['Vert','#536B49'],['Terracotta','#B46B50']];
const sleep = ms => new Promise(resolve=>setTimeout(resolve,ms));
async function api(path,data){
return window.WordclockLocal.run(async()=>{
const controller = new AbortController();const timeout=setTimeout(()=>controller.abort(),5000);
try{const response=await fetch(path,{cache:'no-store',signal:controller.signal,...(data?{method:'POST',body:new URLSearchParams(data)}:{})});if(!response.ok)throw Error('HTTP '+response.status);return await response.json();}finally{clearTimeout(timeout);}
});
}
let installPrompt=null;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;});
window.addEventListener('appinstalled',()=>{installPrompt=null;const d=el('shortcutDialog');if(d&&d.open)d.close();});
document.addEventListener('DOMContentLoaded',()=>{
const dialog=el('setupDialog'),name=el('setupName'),zone=el('setupZone'),color=el('setupColor'),message=el('setupMessage'),next=el('setupNext'),back=el('setupBack'),skip=el('setupSkip'),open=el('setupOpen');
let step=0,busy=false,original=null;
const shortcut=el('shortcutDialog');
function offerShortcut(){
const mobile=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
if((!mobile&&!installPrompt)||navigator.standalone||matchMedia('(display-mode: standalone)').matches)return;
el('shortcutAdd').hidden=false;el('shortcutHelp').hidden=true;el('shortcutAddressHelp').hidden=true;el('shortcutClose').textContent='Plus tard';
if(!shortcut.open)shortcut.showModal();
}
el('shortcutAdd').onclick=async()=>{
if(installPrompt){const prompt=installPrompt;installPrompt=null;try{await prompt.prompt();const choice=await prompt.userChoice;if(choice.outcome==='accepted'){shortcut.close();return;}return;}catch(error){}}
const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
el('shortcutHelp').textContent=ios?'Dans Safari, touchez Partager, puis Sur l’écran d’accueil.':/Android/i.test(navigator.userAgent)?'Dans Chrome, ouvrez le menu ⋮, puis Ajouter à l’écran d’accueil (ou Créer un raccourci).':'Utilisez le menu de votre navigateur pour installer cette page ou créer un raccourci, si cette option est disponible.';
el('shortcutHelp').hidden=false;
const note=el('shortcutAddressHelp');note.textContent=location.hostname==='wordclock.local'?'Si vous êtes dans la fenêtre de connexion Wi-Fi, ouvrez cette page dans votre navigateur habituel.':'Vous utilisez actuellement une adresse IP qui peut changer. Pour un raccourci durable, essayez l’adresse locale dans Réglages > Accéder à mon horloge avant de créer le raccourci.';note.hidden=false;
el('shortcutAdd').hidden=true;el('shortcutClose').textContent='Terminer';
};
el('shortcutClose').onclick=()=>shortcut.close();
el('accessInstall').onclick=()=>{if(navigator.standalone||matchMedia('(display-mode: standalone)').matches){el('accessMessage').textContent='Vous utilisez déjà le mode application.';return;}el('shortcutAdd').hidden=false;el('shortcutHelp').hidden=true;el('shortcutAddressHelp').hidden=true;el('shortcutClose').textContent='Plus tard';if(!shortcut.open)shortcut.showModal();};
const handoff=new URLSearchParams(location.search).get('shortcut')==='1';
if(handoff){const u=new URL(location.href);u.searchParams.delete('shortcut');history.replaceState(null,'',u.pathname+u.search+u.hash);}
const deviceName=el('deviceName'),deviceZone=el('deviceZone'),deviceStatus=el('deviceSummary');
let deviceTimer=null,deviceBusy=false,devicePending={},deviceRevision=0;
for(const[value,label]of zones){zone.add(new Option(label,value));deviceZone.add(new Option(label,value));}
function validName(value){return value.trim()&&new TextEncoder().encode(value.trim()).length<=48&&!/[\x00-\x1f\x7f]/.test(value);}
function queueDevice(key,value,delay){
deviceRevision++;devicePending[key]=value;clearTimeout(deviceTimer);deviceStatus.textContent='Enregistrement…';open.disabled=true;
deviceTimer=setTimeout(()=>{deviceTimer=null;saveDevice();},delay);
}
async function saveDevice(){
if(deviceBusy||deviceTimer!==null)return;if(!Object.keys(devicePending).length){open.disabled=false;return;}
const changes=devicePending,revision=deviceRevision;devicePending={};deviceBusy=true;
try{await api('/api/device',changes);await waitSaved(changes);if(revision===deviceRevision)deviceStatus.textContent='Enregistré';}
catch(e){if(revision===deviceRevision)deviceStatus.textContent='Enregistrement non confirmé. Modifiez à nouveau le réglage pour réessayer.';}
finally{deviceBusy=false;if(Object.keys(devicePending).length&&deviceTimer===null)saveDevice();else if(deviceTimer===null)open.disabled=false;}
}
deviceName.addEventListener('input',()=>{const value=deviceName.value.trim();if(!validName(deviceName.value)){deviceRevision++;delete devicePending.name;deviceStatus.textContent='Saisissez un nom valide de 48 octets maximum.';return;}queueDevice('name',value,700);});
deviceZone.addEventListener('change',()=>queueDevice('timezone',deviceZone.value,0));
for(const[label,value]of colors){const b=document.createElement('button');b.type='button';b.textContent=label;b.dataset.color=value;const sw=document.createElement('span');sw.className='face-swatch';sw.style.background=value;b.prepend(sw);b.onclick=()=>{color.value=value;paint();};el('setupPresets').append(b);}
window.WordclockStudioVisual.matrixPreview(el('setupFace'));
function paint(){const c=color.value;const rgb=[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));const light=rgb[0]*.299+rgb[1]*.587+rgb[2]*.114;el('setupFace').style.setProperty('--face-color',c);el('setupFace').style.setProperty('--face-unlit',`rgb(${rgb.map(n=>Math.round(n*.78+(light>135?0:255)*.22)).join(',')})`);for(const b of el('setupPresets').children)b.setAttribute('aria-pressed',String(b.dataset.color.toLowerCase()===c));}
color.oninput=paint;
function render(){el('setupTitle').textContent=['Bienvenue','À la bonne heure','Votre façade','Vérifier votre configuration'][step];el('setupProgress').textContent=`Étape ${step+1} sur 4`;el('setupBar').value=step+1;for(const section of dialog.querySelectorAll('[data-setup-step]'))section.hidden=Number(section.dataset.setupStep)!==step;back.hidden=step===0;next.textContent=step===3?'Enregistrer et terminer':'Continuer';skip.textContent=original&&original.setupComplete?'Annuler':'Passer la configuration';el('setupSummary').textContent=`${name.value.trim()} — ${zone.options[zone.selectedIndex].text} — ${color.value}`;}
function lock(value){busy=value;for(const control of dialog.querySelectorAll('button,input,select'))control.disabled=value;}
function valid(){return name.value.trim()&&new TextEncoder().encode(name.value.trim()).length<=48&&!/[\x00-\x1f\x7f]/.test(name.value);}
async function waitSaved(expected,face){for(let i=0;i<20;i++){await sleep(1000);const d=await api('/api/device');if(d.saveFailed)throw Error('Sauvegarde non confirmée');if(!d.savePending){if(Object.keys(expected).some(k=>d[k]!==expected[k]))throw Error('Paramètres modifiés ailleurs');if(face&&(await api('/api/appearance')).faceColor.toLowerCase()!==face.toLowerCase())throw Error('Couleur non confirmée');return d;}}throw Error('Délai de sauvegarde dépassé');}
async function finish(ignore){if(busy)return;lock(true);message.textContent='Enregistrement…';try{if(!ignore){const expected={name:name.value.trim(),timezone:zone.value};await api('/api/device',expected);await api('/api/appearance',{faceColor:color.value});await waitSaved(expected,color.value);}await api('/api/device',{setupComplete:'true'});await waitSaved({setupComplete:true});const first=!original.setupComplete;const u=new URL(location.href);if(first||handoff)u.searchParams.set("shortcut","1");location.replace(u.href);}catch(e){message.textContent='Enregistrement non confirmé. Réessayez. Des modifications peuvent déjà avoir été appliquées. ('+e.message+')';lock(false);}}
next.onclick=()=>{if(busy)return;if(step===0&&!valid()){message.textContent='Saisissez un nom valide de 48 octets maximum.';return;}message.textContent='';if(step===3){finish(false);return;}step++;render();};
back.onclick=()=>{if(!busy&&step>0){step--;message.textContent='';render();}};
skip.onclick=()=>{if(busy)return;if(original.setupComplete){dialog.close();return;}finish(true);};
dialog.addEventListener('cancel',e=>{e.preventDefault();});
async function launch(d){const a=await api('/api/appearance');if(!/^#[0-9a-f]{6}$/i.test(a.faceColor))throw Error('Couleur invalide');original=d;name.value=d.name;zone.value=d.timezone;if(!d.setupComplete){let guess=Intl.DateTimeFormat().resolvedOptions().timeZone;if(guess==='UTC')guess='Etc/UTC';if(zones.some(z=>z[0]===guess))zone.value=guess;}color.value=a.faceColor;paint();step=0;message.textContent='';render();dialog.showModal();}
async function refresh(auto=false){if(deviceBusy||deviceTimer!==null||Object.keys(devicePending).length||document.activeElement===deviceName)return;const revision=deviceRevision;try{const d=await api('/api/device');if(revision!==deviceRevision)return;deviceName.value=d.name;deviceZone.value=d.timezone;deviceName.disabled=false;deviceZone.disabled=false;deviceStatus.textContent='';open.disabled=false;if(auto&&!d.setupComplete)await launch(d);else if(auto&&handoff)offerShortcut();}catch(e){deviceStatus.textContent='Configuration indisponible. Réessayez.';open.disabled=false;}}
open.onclick=async()=>{open.disabled=true;try{await launch(await api('/api/device'));}catch(e){el('deviceSummary').textContent='Configuration indisponible. Réessayez.';}finally{open.disabled=false;}};
refresh(true);el('settingsTab').addEventListener('click',()=>refresh());
},{once:true});
})();
;
(()=>{'use strict';document.addEventListener('DOMContentLoaded',()=>{
const el=id=>document.getElementById(id),dialog=el('maintenanceDialog'),form=el('maintenanceForm'),password=el('maintenancePassword'),confirm=el('maintenanceConfirm'),msg=el('maintenanceMessage'),submit=el('maintenanceSubmit'),close=el('maintenanceClose');
let action='',busy=false,diagnostic='';
const config={info:['Informations système','État actuel de votre horloge.'],restart:['Redémarrer l’horloge','La connexion sera interrompue quelques secondes. Vos données seront conservées.'],'reset-settings':['Réinitialiser les réglages','Les couleurs, effets, luminosités, transitions et le mode nuit seront réinitialisés. Le Wi-Fi, les personnalisations des thèmes, le nom, le fuseau horaire et la façade seront conservés.'],'factory-reset':['Restaurer les paramètres d’usine','Toutes les personnalisations, les réglages et les identifiants Wi-Fi seront effacés. Cette action est irréversible.']};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function request(path,opts={}){return window.WordclockLocal.run(async()=>{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),5000);try{const r=await fetch(path,{cache:'no-store',...opts,signal:controller.signal});if(!r.ok){const errors={401:'Mot de passe incorrect.',403:'Action refusée.',409:'Horloge occupée ou sauvegarde en attente. Réessayez dans quelques secondes.',503:'Stockage indisponible ou opération non confirmée.'};throw new Error(errors[r.status]||`Erreur HTTP ${r.status}`);}return await r.json();}finally{clearTimeout(timer);}});}
function lock(v){busy=v;for(const c of dialog.querySelectorAll('button,input'))c.disabled=v;}
function info(){return request('/api/system');}
const kib=n=>Number.isFinite(n)?`${(n/1024).toFixed(1)} Kio`:'Indisponible';
async function refresh(){lock(true);diagnostic='';msg.textContent='Chargement…';try{const d=await info();const rows=[['Firmware',d.firmware],['Interface web',d.webVersion||'Inconnue'],['Adresse locale',d.hostname],['Adresse IP',d.ip],['Signal Wi-Fi',`${d.rssi} dBm`],['Fonctionnement',`${Math.floor(d.uptime/86400)} j ${Math.floor(d.uptime/3600)%24} h ${Math.floor(d.uptime/60)%60} min`],['RAM libre',kib(d.freeHeap)],['Plus grand bloc',kib(d.maxFreeBlock)],['Fragmentation',Number.isFinite(d.heapFragmentation)?`${d.heapFragmentation} %`:'Indisponible'],['RAM minimale échantillonnée',kib(d.sampledMinHeap)],['Bloc minimal échantillonné',kib(d.sampledMinBlock)],['Marge mémoire MAJ (indicative)',typeof d.updateMemoryMargin==='boolean'?(d.updateMemoryMargin?'Seuil initial atteint':'Insuffisante'):'Indisponible'],['Météo',d.weatherStatus?`${d.weatherValid?'Données valides':'Données indisponibles'} · ${d.weatherStatus}`:'Indisponible'],['Flash',kib(d.flashBytes)],['Stockage',d.storageReady?'Opérationnel':'Indisponible'],['Stockage utilisé',`${kib(d.storageUsed)} / ${kib(d.storageTotal)}`],['Sauvegarde',d.saveFailed?'Erreur':d.savePending?'En attente':'Terminée']];const dl=el('maintenanceValues');dl.replaceChildren();for(const[k,v]of rows){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=v;dl.append(dt,dd);}diagnostic=rows.map(r=>r.join(': ')).join('\n');const bar=el('maintenanceStorage');bar.hidden=!(d.storageTotal>0&&Number.isFinite(d.storageUsed));bar.value=bar.hidden?0:100*d.storageUsed/d.storageTotal;msg.textContent='';}catch(e){msg.textContent=e.message;}finally{lock(false);}}
for(const b of document.querySelectorAll('[data-maintenance]'))b.onclick=()=>{if(busy)return;action=b.dataset.maintenance;const c=config[action];el('maintenanceTitle').textContent=c[0];el('maintenanceDescription').textContent=c[1];msg.textContent='';password.value='';confirm.value='';form.hidden=action==='info';el('maintenanceInfo').hidden=action!=='info';el('maintenanceConfirmWrap').hidden=action!=='factory-reset';confirm.required=action==='factory-reset';submit.textContent=action==='factory-reset'?'Tout effacer':'Confirmer';submit.classList.toggle('danger',action==='factory-reset');dialog.showModal();if(action==='info')refresh();};
close.onclick=()=>{if(!busy){password.value='';dialog.close();}};dialog.addEventListener('cancel',e=>{e.preventDefault();close.click();});el('maintenanceRefresh').onclick=refresh;
el('maintenanceCopy').onclick=async()=>{if(!diagnostic)return;try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(diagnostic);else{const t=document.createElement('textarea');t.value=diagnostic;dialog.append(t);t.select();let ok=false;try{ok=document.execCommand('copy');}finally{t.remove();}if(!ok)throw Error();}msg.textContent='Diagnostic copié.';}catch{msg.textContent='Copie automatique indisponible. Sélectionnez les informations affichées.';}};
form.onsubmit=async e=>{e.preventDefault();if(busy)return;if(action==='factory-reset'&&confirm.value!=='EFFACER'){msg.textContent='Saisissez exactement EFFACER.';return;}lock(true);msg.textContent='Envoi de la demande…';let accepted=false;try{const auth=btoa(Array.from(new TextEncoder().encode('admin:'+password.value),b=>String.fromCharCode(b)).join(''));password.value='';const d=await request('/api/system/'+action,{method:'POST',headers:{Authorization:'Basic '+auth,'X-Wordclock-Action':action,'Content-Type':'application/x-www-form-urlencoded'},body:action==='factory-reset'?'confirm=ERASE':''});if(!d.ok)throw Error('Demande non confirmée.');accepted=true;form.hidden=true;if(action==='factory-reset'){msg.textContent='Restauration acceptée. Attendez le redémarrage, puis connectez-vous à Wordclock-Setup (mot de passe Wordclock123). Ouvrez http://192.168.4.1 si nécessaire. La fin de la restauration sera confirmée lors de la nouvelle installation.';return;}if(action==='reset-settings'){for(let i=0;i<20;i++){await sleep(1000);const state=await info();if(state.saveFailed)throw Error('Échec de sauvegarde.');if(!state.savePending){location.reload();return;}}throw Error('Délai de sauvegarde dépassé.');}msg.textContent='Redémarrage accepté. Attente de la reconnexion…';await sleep(5000);for(let i=0;i<15;i++){try{const state=await info();if(!state.restartPending){location.reload();return;}}catch{}await sleep(1500);}throw Error('Reconnexion non confirmée. Essayez wordclock.local.');}catch(e){msg.textContent=(accepted?'Opération acceptée, mais résultat final non confirmé. ':'Demande non confirmée. Vérifiez l’état de l’horloge avant de réessayer. ')+e.message;}finally{password.value='';lock(false);}};
},{once:true});})();
(()=>{'use strict';
const BASE='https://ccachin.github.io/Wordclock-2.0/';
const names='index.html style.css app.js night.js studio.js theme-rules.js studio-visual.js community.js setup.js maintenance.js icon.svg manifest.json'.split(' ');
const decoder=new TextDecoder('utf-8',{fatal:true});
const version=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-dev(?:\.(0|[1-9]\d*))?)?$/;
function cmp(a,b){const x=version.exec(a),y=version.exec(b);if(!x||!y)throw Error('Version invalide');for(let i=1;i<=3;i++){const d=Number(x[i])-Number(y[i]);if(d)return Math.sign(d);}return a.includes('-dev')===b.includes('-dev')?Math.sign(Number(x[4]||0)-Number(y[4]||0)):a.includes('-dev')?-1:1;}
async function sha(bytes){if(globalThis.crypto?.subtle)return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
const k=[],h=[];for(let n=2;k.length<64;n++){let prime=true;for(let d=2;d*d<=n;d++)if(n%d===0){prime=false;break;}if(prime){if(h.length<8)h.push((Math.sqrt(n)%1*4294967296)|0);k.push((Math.cbrt(n)%1*4294967296)|0);}}
const p=new Uint8Array(Math.ceil((bytes.length+9)/64)*64);p.set(bytes);p[bytes.length]=128;const dv=new DataView(p.buffer);dv.setUint32(p.length-4,bytes.length*8);const w=new Int32Array(64),r=(x,n)=>(x>>>n)|(x<<(32-n));for(let o=0;o<p.length;o+=64){for(let i=0;i<16;i++)w[i]=dv.getInt32(o+i*4);for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(r(a,7)^r(a,18)^(a>>>3))+w[i-7]+(r(b,17)^r(b,19)^(b>>>10)))|0;}let[a,b,c,d,e,f,g,j]=h;for(let i=0;i<64;i++){const t=(j+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+k[i]+w[i])|0,u=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))|0;j=g;g=f;f=e;e=(d+t)|0;d=c;c=b;b=a;a=(t+u)|0;}[a,b,c,d,e,f,g,j].forEach((v,i)=>h[i]=(h[i]+v)|0);}return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');}
async function bytes(url,max){const r=await fetch(url,{cache:'no-store',credentials:'omit',signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('HTTP '+r.status);const reader=r.body.getReader(),parts=[];let size=0;try{while(true){const{value,done}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Fichier trop volumineux');parts.push(value);}}finally{await reader.cancel().catch(()=>{});}const out=new Uint8Array(size);let i=0;for(const p of parts){out.set(p,i);i+=p.length;}return out;}
const parse=b=>JSON.parse(decoder.decode(b));
async function checked(url,d,max){if(!d||!Number.isSafeInteger(d.size)||d.size<1||d.size>max||! /^[a-f0-9]{64}$/.test(d.sha256))throw Error('Descripteur invalide');const b=await bytes(url,d.size);if(b.length!==d.size||await sha(b)!==d.sha256)throw Error('Empreinte incorrecte');return b;}
async function unzip(b,m){const v=new DataView(b.buffer,b.byteOffset,b.byteLength),files=new Map();let o=0;while(o+4<=b.length&&v.getUint32(o,true)===0x04034b50){if(o+30>b.length)throw Error('ZIP tronqué');const flags=v.getUint16(o+6,true),method=v.getUint16(o+8,true),compressed=v.getUint32(o+18,true),size=v.getUint32(o+22,true),nl=v.getUint16(o+26,true),xl=v.getUint16(o+28,true),start=o+30+nl+xl;if(flags&~0x800||start+compressed>b.length)throw Error('ZIP non pris en charge');const name=decoder.decode(b.subarray(o+30,o+30+nl)),item=m.files.find(f=>f.path===name);if(!item||files.has(name)||size!==item.size)throw Error('Entrée ZIP invalide');let data=b.subarray(start,start+compressed);if(method===8){if(!globalThis.DecompressionStream)throw Error('Navigateur incompatible avec ZIP');const reader=new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();const out=new Uint8Array(size);let pos=0;try{while(true){const{done,value}=await reader.read();if(done)break;if(pos+value.length>size)throw Error('ZIP trop volumineux');out.set(value,pos);pos+=value.length;}}finally{await reader.cancel().catch(()=>{});}data=out;if(pos!==size)throw Error('ZIP incomplet');}else if(method!==0)throw Error('Compression inconnue');if(data.length!==size||await sha(data)!==item.sha256)throw Error('Ressource invalide : '+name);files.set(name,data);o=start+compressed;}if(files.size!==names.length||o+4>b.length||v.getUint32(o,true)!==0x02014b50)throw Error('ZIP incomplet');return files;}
function authorizationPayload(r){
const lines=['WORDCLOCK-RELEASE-AUTH-V1','d1','1',r.version,r.channel,r.firmwareVersion||'-',r.webVersion];
for(const k of['firmware','firmwareSignature','webManifest','web','notes']){const a=r.artifacts[k];lines.push(k+':'+(a?`${a.size}:${a.sha256}`:'-'));}
if(!/^[a-f0-9]{512}$/.test(r.releaseAuthorization||''))throw Error('Signature de publication absente');
return lines.join('\n')+'\n'+r.releaseAuthorization;
}
function validate(m,rel){if(m.format!=='wordclock-web'||m.manifestVersion!==1||m.version!==rel.webVersion||m.compatibility?.webApiVersion!==1||m.fileCount!==12||!Array.isArray(m.files)||m.files.length!==12||new Set(m.files.map(f=>f.path)).size!==12||m.files.some(f=>!names.includes(f.path)||!Number.isSafeInteger(f.size)||f.size<1||f.size>131072||! /^[a-f0-9]{64}$/.test(f.sha256))||m.totalBytes!==m.files.reduce((s,f)=>s+f.size,0)||m.totalBytes>393216)throw Error('Manifeste web invalide');}
document.addEventListener('DOMContentLoaded',()=>{const $=id=>document.getElementById(id),panel=$('updatesPanel');if(!panel)return;const status=$('updateStatus'),progress=$('updateProgress'),install=$('updateInstall'),channel=$('updateChannel'),notes=$('updateNotes');let busy=false,candidate=null,official=false;channel.value='stable';try{if(localStorage.getItem('wordclock.update.channel')==='development')channel.value='development';}catch{}
function lock(v){busy=v;window.WordclockLocal.setBusy(v);for(const e of panel.querySelectorAll('button,input,select'))e.disabled=v;}
function message(s){status.textContent=s;}function bar(n){progress.hidden=false;progress.value=n;}
async function local(path,options={}){return window.WordclockLocal.run(async()=>{const r=await fetch(path,{cache:'no-store',...options,signal:AbortSignal.timeout(30000)});const d=await r.json();if(!r.ok)throw Error(`HTTP ${r.status} : ${d.error||'action refusée'}`);return d;},true);}
const system=()=>local('/api/system');function auth(){const p=prompt('Mot de passe administrateur (réseau local)');return p===null?null:'Basic '+btoa(Array.from(new TextEncoder().encode('admin:'+p),x=>String.fromCharCode(x)).join(''));}
function api(a,action,path,method='POST',body,ticket){return local('/api/system/'+path,{method,headers:{...(a?{Authorization:a}:{}),...(ticket?{'X-Wordclock-Ticket':ticket}:{}),'X-Wordclock-Action':action,...(body instanceof Uint8Array?{'Content-Type':'text/plain'}:{})},body});}
async function officialTicket(r,kind){const body=new TextEncoder().encode(authorizationPayload(r));for(let i=0;i<12;i++){try{const d=await api(null,'official-update','official/authorize?'+new URLSearchParams({kind,experimental:r.channel==='development'?'1':'0'}),'POST',body);if(!/^[a-f0-9]{32}$/.test(d.token))throw Error('Autorisation invalide');return d.token;}catch(e){if(i===11||!(/HTTP 429|Insufficient verification memory|HTTP 409 : Update not ready/.test(e.message)))throw e;message('Préparation sécurisée de la mise à jour…');await new Promise(r=>setTimeout(r,5000));}}}
async function check(quiet=false){if(busy||window.WordclockLocal.busy)return;if(quiet){busy=true;for(const e of panel.querySelectorAll('button,input,select'))e.disabled=true;}else lock(true);candidate=null;$('homeUpdatePanel').hidden=true;$('updateAvailable').textContent='';install.hidden=true;notes.hidden=true;progress.hidden=true;message('Recherche…');try{
const d=await system();official=d.officialUpdates===true;const experimentalAllowed=!official||d.releaseChannel==='development';channel.querySelector('option[value=development]').disabled=!experimentalAllowed;if(!experimentalAllowed)channel.value='stable';$('updateInstalled').textContent=`Firmware : ${d.firmware} · Interface : ${d.webVersion||'développement / inconnue'}`;
const c=parse(await bytes(BASE+'catalog.json',32768));if(c.format!=='wordclock-release-catalog'||c.version!==1||!Array.isArray(c.releases))throw Error('Catalogue invalide');
const entries=c.releases.filter(e=>e.channel===channel.value&&version.test(e.version)&&e.manifest===`releases/${e.version}/release.json`).sort((a,b)=>cmp(b.version,a.version));
let web=null,fw=null;for(const e of entries){if(official&&cmp(e.version,'3.8.0-dev')<0)continue;const raw=await bytes(BASE+e.manifest,8192);if(await sha(raw)!==e.sha256)throw Error('Empreinte du manifeste incorrecte');const r=parse(raw),root=BASE+`releases/${e.version}/`;
if(r.format!=='wordclock-release'||r.manifestVersion!==1||r.version!==e.version||r.channel!==channel.value)throw Error('Publication invalide');if(r.compatibility?.board!=='d1'||r.compatibility?.webApiVersion!==d.webApiVersion)continue;if(official&&!/^[a-f0-9]{512}$/.test(r.releaseAuthorization||''))continue;
if(!/^\d+\.\d+\.\d+$/.test(r.webVersion)||r.artifacts?.web?.path!=='web.zip'||r.artifacts?.webManifest?.path!=='web-manifest.json'||r.artifacts?.notes?.path!=='CHANGELOG.md')throw Error('Publication invalide');
if(!web||cmp(r.webVersion,web.r.webVersion)>0)web={r,root};if(r.firmwareVersion!=null){if(!version.test(r.firmwareVersion)||r.artifacts.firmware?.path!=='firmware.bin'||r.artifacts.firmwareSignature?.path!=='firmware.sig')throw Error('Firmware invalide');if(!fw||cmp(r.firmwareVersion,fw.r.firmwareVersion)>0)fw={r,root};}}
if(!web){message('Aucune publication compatible sur ce canal.');return;}
$('updateAvailable').textContent=`Disponibles — Firmware : ${fw?.r.firmwareVersion||'aucun'} · Interface : ${web.r.webVersion}`;
const body=$('updateNotesBody');body.replaceChildren();for(const item of[web,...(fw&&fw.r.version!==web.r.version?[fw]:[])]){const heading=document.createElement('h4');heading.textContent=item.r.version;body.append(heading);const text=decoder.decode(await checked(item.root+'CHANGELOG.md',item.r.artifacts.notes,32768));const pre=document.createElement('p');pre.style.whiteSpace='pre-wrap';pre.textContent=text;body.append(pre);}
$('updateNotesTitle').textContent='Notes de publication';notes.open=false;notes.hidden=false;
const w=!d.webVersion||cmp(web.r.webVersion,d.webVersion)>0||(d.webVersionState!=='manifest'&&cmp(web.r.webVersion,d.webVersion)>=0);const f=fw&&cmp(fw.r.firmwareVersion,d.firmware)>0;candidate={web:w?web:null,fw:f?fw:null};install.hidden=!(w||f);$('homeUpdatePanel').hidden=!(w||f);$('homeUpdateText').textContent='Version '+(f?fw.r.firmwareVersion:web.r.webVersion)+' disponible.';message(w||f?'Une mise à jour est disponible.':'Aucune version plus récente sur ce canal.');}catch(e){message('Recherche impossible : '+e.message);}finally{if(quiet){busy=false;for(const e of panel.querySelectorAll('button,input,select'))e.disabled=false;}else lock(false);}}
async function webTransfer(a,raw,m,files,rel,begin=0,end=100){let id=null,activating=false,ticket=null;const progress=n=>bar(begin+(end-begin)*n/100);try{if(!a)ticket=await officialTicket(rel,'web');const form=new FormData();form.append('manifest',new Blob([raw],{type:'application/json'}),'web-manifest.json');const req=(path,method='POST',body)=>api(a,'web-update','web-update/'+path,method,body,ticket);const before=await system();const start=await req('start','POST',form);id=start.id;if(!Number.isSafeInteger(id)||id<=0)throw Error('Session invalide');let sent=0;for(const[name,data]of files){for(let offset=0;offset<data.length;offset+=512){const chunk=data.subarray(offset,offset+512),q=new URLSearchParams({id,name,offset});const result=await req('chunk?'+q,'PUT',chunk);if(result.offset!==offset+chunk.length)throw Error('Décalage incorrect');sent+=chunk.length;progress(95*sent/m.totalBytes);message('Installation de l’interface : '+Math.floor(100*sent/m.totalBytes)+' %');}}message('Vérification sur l’horloge…');const verified=await req('verify?id='+id);if(!verified.verified||verified.verifiedFiles!==12)throw Error('Vérification non confirmée');activating=true;const switched=await req('activate?id='+id+'&confirm=SWITCH');if(!switched.activated)throw Error('Activation non confirmée');id=null;const after=await system();if(after.webSlot===before.webSlot||after.webSlotGeneration!==switched.generation||after.webVersion!==m.version||after.webVersionState!=='manifest')throw Error('Version finale non confirmée');progress(100);message('Interface installée.');}catch(e){if(id!==null&&!activating){try{await api(a,'web-update','web-update/cancel?id='+id,'POST',undefined,ticket);}catch{}}throw e;}}
async function transfer(){if(busy||!candidate)return;const{web,fw}=candidate;if(!web&&!fw)return;if(!confirm('Installer la mise à jour '+(fw?fw.r.firmwareVersion:web.r.webVersion)+(channel.value==='development'?' (version expérimentale)':'')+' ? L’horloge pourra redémarrer.'))return;const a=official?null:auth();if(!official&&!a)return;$('homeUpdatePanel').hidden=true;lock(true);try{message('Téléchargement et vérification…');bar(0);let data,sig,raw,m,files;if(fw){data=await checked(fw.root+'firmware.bin',fw.r.artifacts.firmware,1044464);sig=await checked(fw.root+'firmware.sig',fw.r.artifacts.firmwareSignature,256);}if(web){raw=await checked(web.root+'web-manifest.json',web.r.artifacts.webManifest,4096);m=parse(raw);validate(m,web.r);files=await unzip(await checked(web.root+'web.zip',web.r.artifacts.web,393216),m);}const split=fw&&web?Math.round(100*data.length/(data.length+m.totalBytes)):fw?100:0;if(fw)await firmwareTransfer(a,data,sig,fw.r.firmwareVersion,fw.r,0,split);if(web)await webTransfer(a,raw,m,files,web.r,split,100);message('Mise à jour confirmée. Rechargement…');setTimeout(()=>location.replace('/?updated='+Date.now()),800);}catch(e){message('Mise à jour interrompue ou résultat à vérifier : '+e.message);}finally{candidate=null;install.hidden=true;lock(false);}}
async function rollback(){if(busy||!confirm('Restaurer l’interface précédente ?'))return;const a=auth();if(!a)return;lock(true);try{const d=await api(a,'web-update','web-update/rollback?confirm=SWITCH');if(!d.activated)throw Error('Restauration non confirmée');const s=await system();if(s.webSlot!==d.webSlot||s.webSlotGeneration!==d.generation)throw Error('État final non confirmé');location.replace('/?updated='+Date.now());}catch(e){message(e.message);}finally{lock(false);}}
async function firmwareTransfer(a,data,sig,target,rel,begin=0,end=100){let token=null,activating=false;const progress=n=>bar(begin+(end-begin)*n/100);const req=(path,method='POST',body)=>api(a,'firmware-update','firmware/'+path,method,body);try{if(data[0]!==233||data.length<12288||data.length>1044464||sig.length!==256)throw Error('Image ou signature invalide');const h=await sha(data),before=await system(),signature=Array.from(sig,v=>v.toString(16).padStart(2,'0')).join('');const pre=await api(a,'firmware-update','firmware','GET');if(pre.protocol!==2||!pre.ready)throw Error('Protocole firmware indisponible');let ticket;if(!a){ticket={token:await officialTicket(rel,'firmware')};}else for(let i=0;i<12;i++){try{ticket=await req('authorize?'+new URLSearchParams({size:data.length,sha256:h,confirm:'INSTALL',signature}));break;}catch(e){if(i===11||!e.message.includes('HTTP 503')||!e.message.includes('Insufficient verification memory'))throw e;message('Préparation du firmware : mémoire temporairement indisponible…');await new Promise(r=>setTimeout(r,5000));}}
if(!/^[0-9a-f]{32}$/.test(ticket.token))throw Error('Autorisation invalide');const session=await req('start?'+new URLSearchParams({token:ticket.token,confirm:'INSTALL'}));token=session.token;if(!/^[0-9a-f]{32}$/.test(token)||![512,1024].includes(session.chunkSize)||session.offset!==0)throw Error('Session invalide');for(let offset=0;offset<data.length;offset+=session.chunkSize){const block=data.subarray(offset,offset+session.chunkSize),r=await req('chunk?'+new URLSearchParams({token,offset}),'PUT',block);if(r.offset!==offset+block.length)throw Error('Décalage invalide');progress(95*r.offset/data.length);message('Installation du logiciel : '+Math.floor(100*r.offset/data.length)+' %');}const v=await req('verify?token='+token);if(!v.verified)throw Error('Intégrité non confirmée');activating=true;const d=await req('activate?token='+token+'&confirm=INSTALL');if(!d.installationScheduled||!d.sha256Verified)throw Error('Activation non confirmée');message('Redémarrage attendu…');for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,5000));try{const state=await system();if(state.buildId!==before.buildId&&state.sketchBytes===data.length&&(!target||state.firmware===target)){progress(100);message('Nouveau logiciel confirmé.');return;}}catch{}}throw Error('Nouveau firmware non confirmé');}catch(e){if(token&&!activating){try{await req('cancel?token='+token);}catch{}}throw e;}}
async function firmware(){const f=$('updateFirmware').files[0],sf=$('updateSignature').files[0];if(busy||!f||!sf)return;if(sf.size!==256||f.size<12288||f.size>1044464){message('Firmware ou signature invalide.');return;}if(!confirm('Installer ce firmware signé ? L’horloge redémarrera.'))return;const a=auth();if(!a)return;lock(true);try{await firmwareTransfer(a,new Uint8Array(await f.arrayBuffer()),new Uint8Array(await sf.arrayBuffer()),null);}catch(e){message('Installation interrompue ou résultat à vérifier : '+e.message);}finally{lock(false);$('updateFirmware').value='';$('updateSignature').value='';}}
$('updateCheck').onclick=()=>check();channel.onchange=()=>{try{localStorage.setItem('wordclock.update.channel',channel.value);}catch{}check();};install.onclick=transfer;$('homeUpdateOpen').onclick=()=>{$('settingsTab').click();document.querySelector('[data-settings=system]').click();void transfer();};setTimeout(()=>{if(!document.hidden&&!busy&&!window.WordclockLocal.busy)check(true);},4000);$('updateRollback').onclick=rollback;$('updateManual').onclick=firmware;message('Recherchez les mises à jour disponibles.');window.WordclockLocal.run(async()=>{const r=await fetch('/api/system',{cache:'no-store',signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('HTTP '+r.status);const d=await r.json();$('updateInstalled').textContent=`Firmware : ${d.firmware} · Interface : ${d.webVersion||'développement / inconnue'}`;}).catch(()=>{});
},{once:true});})();
